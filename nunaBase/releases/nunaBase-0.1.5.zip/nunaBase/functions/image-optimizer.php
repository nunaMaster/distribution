<?php
// Exit if accessed directly.
if (!defined('ABSPATH'))
    exit;

/**
 * Image Optimizer for nunaBase Theme
 * - Compress & resize on upload
 * - Convert to WebP
 * - CLI re-optimization
 */

// ------------------------------------
// ✅ Optimize on Upload
// ------------------------------------
add_filter('wp_handle_upload', function ($upload) {
    $file_path = $upload['file'];
    $mime_type = mime_content_type($file_path);

    if (!in_array($mime_type, ['image/jpeg', 'image/png']))
        return $upload;

    $max_width = 1920;
    $jpeg_quality = 75;
    $webp_quality = 80;

    $image = create_image_from_file($file_path, $mime_type);
    if (!$image)
        return $upload;

    [$width, $height] = [imagesx($image), imagesy($image)];
    if ($width > $max_width) {
        $new_height = intval($height * $max_width / $width);
        $resized = imagescale($image, $max_width, $new_height);
        imagedestroy($image);
        $image = $resized;
    }

    save_image_by_type($image, $file_path, $mime_type, $jpeg_quality);

    if (function_exists('imagewebp')) {
        $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $file_path);
        imagewebp($image, $webp_path, $webp_quality);
    }

    imagedestroy($image);
    return $upload;
});

// ------------------------------------
// ✅ Convert WebP for All Sizes
// ------------------------------------
add_filter('wp_generate_attachment_metadata', function ($metadata, $attachment_id) {
    if (empty($metadata['sizes']))
        return $metadata;

    $upload_dir = wp_upload_dir();
    $base_path = trailingslashit($upload_dir['basedir']);
    $subdir = trailingslashit(dirname($metadata['file']));

    foreach ($metadata['sizes'] as $data) {
        $file = $base_path . $subdir . $data['file'];
        $webp = preg_replace('/\.(jpe?g|png)$/i', '.webp', $file);

        if (!file_exists($file) || file_exists($webp))
            continue;

        $image = create_image_from_file($file);
        if ($image && function_exists('imagewebp')) {
            imagewebp($image, $webp, 80);
            imagedestroy($image);
        }
    }
    return $metadata;
}, 10, 2);

// ------------------------------------
// ✅ Replace <img> with <picture>
// ------------------------------------
add_filter('wp_get_attachment_image', function ($html, $id, $size, $icon, $attr) {
    $src = wp_get_attachment_image_src($id, $size);

    if (!$src)
        return $html;

    $upload = wp_get_upload_dir();
    $original_url = $src[0];
    $webp_url = preg_replace('/\.(jpe?g|png)$/i', '.webp', $original_url);
    $relative_path = str_replace($upload['baseurl'], '', $webp_url);
    $webp_path = $upload['basedir'] . $relative_path;

    // Fallback alt
    $alt = $attr['alt'] ?? get_post_meta($id, '_wp_attachment_image_alt', true);
    if (!$alt) {
        $alt = get_the_title($id) ?: basename(get_attached_file($id));
    }
    $alt = esc_attr($alt);

    [$width, $height] = [$src[1], $src[2]];
    if ($width <= 1 || $height <= 1) {
        $meta = wp_get_attachment_metadata($id);
        if (!empty($meta['width']) && !empty($meta['height'])) {
            $width = $meta['width'];
            $height = $meta['height'];
        }
    }

    $srcset = wp_get_attachment_image_srcset($id, $size);
    $webp_srcset = $srcset ? preg_replace('/\.(jpe?g|png)/i', '.webp', $srcset) : '';
    $sizes = $attr['sizes'] ?? '(max-width: 480px) 100vw, (max-width: 768px) 100vw, (max-width: 1024px) 90vw, (max-width: 1440px) 80vw, 1440px';
    $type = wp_check_filetype($original_url)['type'] ?? 'image/jpeg';

    $is_small = $width <= get_option('thumbnail_size_w', default_value: 480);

    if ($is_small || !$srcset || !$webp_srcset || !file_exists($webp_path)) {
        $final_src = file_exists($webp_path) ? $webp_url : $original_url;

        return sprintf(
            '<img src="%s" width="%d" height="%d" alt="%s"%s%s>',
            esc_url($final_src),
            $width,
            $height,
            $alt,
            isset($attr['loading']) ? ' loading="' . esc_attr($attr['loading']) . '"' : '',
            isset($attr['decoding']) ? ' decoding="' . esc_attr($attr['decoding']) . '"' : ''
        );
    }

    return sprintf(
        '<picture>
            <source srcset="%s" sizes="%s" type="image/webp">
            <source srcset="%s" sizes="%s" type="%s">
            <img src="%s" width="%d" height="%d" alt="%s"%s%s>
        </picture>',
        esc_attr($webp_srcset),
        esc_attr($sizes),
        esc_attr($srcset),
        esc_attr($sizes),
        esc_attr($type),
        esc_url($original_url),
        $width,
        $height,
        $alt,
        isset($attr['loading']) ? ' loading="' . esc_attr($attr['loading']) . '"' : '',
        isset($attr['decoding']) ? ' decoding="' . esc_attr($attr['decoding']) . '"' : ''
    );
}, 10, 5);

// ------------------------------------
// ✅ Replace image srcset URL with WebP if exists
// ------------------------------------
add_filter('wp_calculate_image_srcset', function ($sources) {
    $upload_dir = wp_get_upload_dir();
    $base_dir = trailingslashit($upload_dir['basedir']);
    $base_url = trailingslashit($upload_dir['baseurl']);

    foreach ($sources as &$source) {
        $src = $source['url'];
        if (!preg_match('/\.(jpe?g|png)$/i', $src)) {
            continue;
        }

        $webp_url = preg_replace('/\.(jpe?g|png)$/i', '.webp', $src);
        $relative_path = str_replace($base_url, '', $webp_url);
        $webp_path = $base_dir . ltrim($relative_path, '/');

        if (file_exists($webp_path)) {
            $source['url'] = $webp_url;
        }
    }

    return $sources;
});

/**
 * Get WebP image URL if available, otherwise fallback to original.
 *
 * @param int $attachment_id Attachment ID.
 * @param string|array $size Image size name or array(width, height).
 * @return string Image URL (WebP if exists).
 */
function nuna_get_image_url($attachment_id, $size = 'full')
{
    if (!wp_attachment_is_image($attachment_id)) {
        return '';
    }

    // Get original image URL
    $url = wp_get_attachment_image_url($attachment_id, $size);
    if (!$url)
        return '';

    // Build WebP version path
    $webp_url = preg_replace('/\.(jpe?g|png)$/i', '.webp', $url);
    $upload_dir = wp_get_upload_dir();
    $relative_path = str_replace($upload_dir['baseurl'], '', $webp_url);
    $webp_path = $upload_dir['basedir'] . '/' . ltrim($relative_path, '/');

    // Check if WebP exists
    return file_exists($webp_path) ? $webp_url : $url;
}

// ------------------------------------
// ✅ WP-CLI: Optimize all images
// ------------------------------------
if (defined('WP_CLI') && WP_CLI && class_exists('WP_CLI_Command')) {
    class Nuna_Image_Optimizer_CLI extends WP_CLI_Command
    {
        private $max_width = 1920;
        private $jpeg_quality = 75;
        private $webp_quality = 80;

        public function __invoke()
        {
            WP_CLI::log("🔥 Optimizer CLI started");

            $images = get_posts([
                'post_type' => 'attachment',
                'post_status' => 'inherit',
                'post_mime_type' => ['image/jpeg', 'image/png'],
                'posts_per_page' => -1,
                'fields' => 'ids',
            ]);

            WP_CLI::log("Found " . count($images) . " images...");

            foreach ($images as $id) {
                $this->optimize($id);
            }

            WP_CLI::success('Optimization complete.');
        }

        private function optimize($id)
        {
            $file_path = get_attached_file($id);
            if (!file_exists($file_path))
                return;

            $mime = mime_content_type($file_path);
            if (!in_array($mime, ['image/jpeg', 'image/png']))
                return;

            $image = create_image_from_file($file_path, $mime);
            if (!$image)
                return;

            [$width, $height] = [imagesx($image), imagesy($image)];
            if ($width > $this->max_width) {
                $new_height = intval($height * $this->max_width / $width);
                $resized = imagescale($image, $this->max_width, $new_height);
                if ($resized) {
                    imagedestroy($image);
                    $image = $resized;
                }
            }

            save_image_by_type($image, $file_path, $mime, $this->jpeg_quality);

            if (function_exists('imagewebp')) {
                $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $file_path);
                imagewebp($image, $webp_path, $this->webp_quality);
            }

            imagedestroy($image);

            $meta = wp_get_attachment_metadata($id);
            $upload_dir = wp_upload_dir();
            $base_path = trailingslashit($upload_dir['basedir']);
            $subdir = trailingslashit(dirname($meta['file']));

            if (!empty($meta['sizes'])) {
                foreach ($meta['sizes'] as $data) {
                    $img_path = $base_path . $subdir . $data['file'];
                    $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $img_path);

                    if (!file_exists($img_path) || file_exists($webp_path))
                        continue;

                    $img = create_image_from_file($img_path);
                    if ($img && function_exists('imagewebp')) {
                        imagewebp($img, $webp_path, $this->webp_quality);
                        imagedestroy($img);
                        WP_CLI::log("WebP created: $webp_path");
                    }
                }
            }
        }
    }

    add_action('nuna_image_optimize_cli', [new Nuna_Image_Optimizer_CLI(), '__invoke']);

    WP_CLI::add_command('image optimize', function ($args, $assoc_args) {
        if (is_multisite() && !isset($assoc_args['site'])) {
            $sites = get_sites(['fields' => 'ids']);
            foreach ($sites as $site_id) {
                switch_to_blog($site_id);
                WP_CLI::log("🔄 Site #$site_id: " . get_site_url());
                do_action('nuna_image_optimize_cli');
                restore_current_blog();
            }
        } else {
            do_action('nuna_image_optimize_cli');
        }
    });
}

// ------------------------------------
// ✅ Shared helpers
// ------------------------------------
if (!function_exists('tap')) {
    function tap($value, callable $callback)
    {
        $callback($value);
        return $value;
    }
}

function create_image_from_file($file, $mime = null)
{
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $mime = $mime ?: mime_content_type($file);

    return match ($mime) {
        'image/jpeg' => imagecreatefromjpeg($file),
        'image/png' => tap(imagecreatefrompng($file), function (&$img) {
                imagepalettetotruecolor($img);
                imagealphablending($img, true);
                imagesavealpha($img, true);
            }),
        default => null,
    };
}

function save_image_by_type($image, $path, $mime, $jpeg_quality = 75)
{
    match ($mime) {
        'image/jpeg' => imagejpeg($image, $path, $jpeg_quality),
        'image/png' => imagepng($image, $path, 6),
        default => null,
    };
}