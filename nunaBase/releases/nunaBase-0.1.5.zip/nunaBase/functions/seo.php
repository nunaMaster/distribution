<?php

if (!defined('ABSPATH')) {
    exit;
}

function nuna_render_seo_meta()
{
    $seo_title = get_field('seo_title') ?: get_the_title();
    $seo_description = get_field('seo_description') ?: get_bloginfo('description');
    $seo_image = get_field('seo_image') ?: get_template_directory_uri() . '/screenshot.png';
    $seo_noindex = get_field('seo_noindex');

    $site_name = get_bloginfo('name');
    $full_title = esc_html($seo_title . ' | ' . $site_name);
    $description = esc_attr($seo_description);
    $image = esc_url($seo_image);
    $canonical = esc_url(get_permalink());
    $robots = $seo_noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large';

    echo <<<HTML
        <title>{$full_title}</title>
        <meta name="description" content="{$description}">
        <meta name="robots" content="{$robots}">
        <link rel="canonical" href="{$canonical}">
        <meta property="og:title" content="{$full_title}">
        <meta property="og:description" content="{$description}">
        <meta property="og:url" content="{$canonical}">
        <meta property="og:type" content="website">
        <meta property="og:image" content="{$image}">
        <meta property="og:locale" content="en_US">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="{$full_title}">
        <meta name="twitter:description" content="{$description}">
        <meta name="twitter:image" content="{$image}">
    HTML;
}

