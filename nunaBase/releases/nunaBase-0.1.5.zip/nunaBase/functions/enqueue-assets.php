<?php

/**
 * Load a Vite manifest file and return its parsed array, or null on failure.
 */
function load_vite_manifest($path)
{
    if (!file_exists($path)) {
        error_log("[Vite] Manifest not found: {$path}");
        return null;
    }

    $json = file_get_contents($path);
    $manifest = json_decode($json, true);

    if (!$manifest) {
        error_log("[Vite] Failed to decode JSON: {$path}");
        return null;
    }

    return $manifest;
}

/**
 * Enqueue theme styles and scripts with support for Vite manifests and skin-specific styles.
 */
function enqueue_assets()
{
    $theme_uri = get_template_directory_uri();
    $theme_path = get_template_directory();

    // Enqueue third-party libraries
    wp_enqueue_style('flickity-css', "{$theme_uri}/dist/assets/libs/flickity/flickity.min.css");
    wp_enqueue_script('flickity-js', "{$theme_uri}/dist/assets/libs/flickity/flickity.pkgd.min.js", [], null, true);

    wp_enqueue_style('fancybox-css', "{$theme_uri}/dist/assets/libs/fancybox/fancybox.min.css");
    wp_enqueue_script('fancybox-js', "{$theme_uri}/dist/assets/libs/fancybox/fancybox.umd.min.js", [], null, true);

    // Load main Vite manifest
    $manifest = load_vite_manifest("{$theme_path}/dist/.vite/manifest.json");
    if (!$manifest)
        return;

    // Enqueue compiled SCSS
    if (!empty($manifest['src/scss/styles.scss']['file'])) {
        wp_enqueue_style('nuna-style', "{$theme_uri}/dist/{$manifest['src/scss/styles.scss']['file']}", [], null);
    }

    // Enqueue compiled JS
    if (!empty($manifest['src/js/main.js']['file'])) {
        wp_enqueue_script('nuna-script', "{$theme_uri}/dist/{$manifest['src/js/main.js']['file']}", [], null, true);
    }

    // Determine current environment
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $is_local = in_array($host, ['localhost', '127.0.0.1']) || str_ends_with($host, '.local') || str_ends_with($host, '.test');
    $nuna_hotel_id = get_field('nuna_hotel_id', 'option');

    // Skip if nuna_hotel_id is missing
    if (!$nuna_hotel_id) {
        error_log("[NunaBase] Missing nuna_hotel_id (ACF option).");
        return;
    }

    // Determine paths
    $skin_manifest_path = $is_local
        ? "{$theme_path}/dev/skins/.vite/{$nuna_hotel_id}.manifest.json"
        : ABSPATH . "wp-content/skins/.vite/{$nuna_hotel_id}.manifest.json";

    $skin_base_url = $is_local
        ? "{$theme_uri}/dev/skins/"
        : get_home_url(null, "/wp-content/skins/");

    // Load and enqueue skin CSS
    $skin_manifest = load_vite_manifest($skin_manifest_path);
    if (!$skin_manifest)
        return;

    $skin_key = "src/scss/skins/{$nuna_hotel_id}.scss";
    if (!empty($skin_manifest[$skin_key]['file'])) {
        wp_enqueue_style('skin-style', $skin_base_url . $skin_manifest[$skin_key]['file'], [], null);
    }
}

add_action('wp_enqueue_scripts', 'enqueue_assets');