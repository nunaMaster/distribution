<?php
/**
 * Register [site_name] shortcode and add button to both Classic Editor & ACF WYSIWYG.
 */

if (!defined('ABSPATH'))
    exit;

// Shortcode
add_shortcode('site_name', fn() => get_bloginfo('name'));

add_filter('acf/fields/wysiwyg/toolbars', function ($toolbars) {
    // Add the custom button to the first row of the "Full" toolbar
    $toolbars['Full'][1][] = 'site_name_button';
    return $toolbars;
});

add_action('acf/input/admin_footer', function () {
    ?>
    <script type="text/javascript">
        (function ($) {
            acf.addAction('wysiwyg_tinymce_init', function (ed, id, mceInit, $field) {
                if (typeof tinymce === 'undefined') return;

                // Register the TinyMCE plugin if not already present
                if (!tinymce.editors[id].plugins.site_name_button_plugin) {
                    tinymce.PluginManager.add('site_name_button_plugin', function (editor) {
                        editor.addButton('site_name_button', {
                            text: ' Insert Site Name',
                            icon: 'dashicon dashicons-shortcode',
                            onclick: function () {
                                editor.insertContent('[site_name]');
                            }
                        });
                    });
                }

                // Attach the plugin to the editor config
                if (!mceInit.external_plugins) {
                    mceInit.external_plugins = {};
                }

                mceInit.external_plugins['site_name_button_plugin'] = '';

                // Reinitialize the TinyMCE editor to apply changes
                tinymce.EditorManager.execCommand('mceRemoveEditor', true, id);
                tinymce.EditorManager.execCommand('mceAddEditor', true, id);
            });
        })(jQuery);
    </script>
    <?php
});
