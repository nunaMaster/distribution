<?php
/**
 * Configure image sizes for the theme.
 */

function theme_update_image_options()
{
	$image_options = [
		'thumbnail_size_w' => 480,
		'thumbnail_size_h' => 0,
		'thumbnail_crop' => 0,

		'medium_size_w' => 768,
		'medium_size_h' => 0,

		'large_size_w' => 1280,
		'large_size_h' => 0,
	];

	foreach ($image_options as $option => $value) {
		update_option($option, $value);
	}
}
add_action('after_switch_theme', 'theme_update_image_options');

// Remove unnecessary sizes
add_filter('intermediate_image_sizes', function ($sizes) {
	return array_diff($sizes, ['medium_large']);
});

add_filter('intermediate_image_sizes_advanced', function ($sizes) {
	unset($sizes['1536x1536'], $sizes['2048x2048']);
	return $sizes;
});

// Disable scaled image threshold (no "-scaled" version)
add_filter('big_image_size_threshold', '__return_false');