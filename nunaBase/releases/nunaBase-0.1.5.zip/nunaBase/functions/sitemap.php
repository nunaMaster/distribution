<?php
/**
 * Custom XML Sitemap for NunaBase (Multi-language WPML + Pages only)
 */

if (!defined('ABSPATH'))
    exit;

/**
 * Register custom sitemap routes
 */
add_action('init', function () {
    add_rewrite_rule('^sitemap_index\.xml$', 'index.php?sitemap_type=index', 'top');
    add_rewrite_rule('^([a-zA-Z-]+)/sitemap\.xml$', 'index.php?sitemap_type=language&sitemap_lang=$matches[1]', 'top');
});

add_filter('query_vars', function ($vars) {
    $vars[] = 'sitemap_type';
    $vars[] = 'sitemap_lang';
    return $vars;
});

add_action('template_redirect', function () {
    $type = get_query_var('sitemap_type');
    if (!$type)
        return;

    header('Content-Type: application/xml; charset=utf-8');

    if ($type === 'index') {
        echo nuna_render_sitemap_index();
        exit;
    }

    if ($type === 'language') {
        $lang = get_query_var('sitemap_lang');
        echo nuna_render_sitemap_by_language($lang);
        exit;
    }
});

/**
 * Render the sitemap index file
 */
function nuna_render_sitemap_index()
{
    $langs = apply_filters('wpml_active_languages', null, ['skip_missing' => 0]);
    $base_url = home_url();

    $xml = '<?xml version="1.0" encoding="UTF-8"?>';
    $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    foreach ($langs as $code => $lang) {
        $loc = trailingslashit($base_url) . "$code/sitemap.xml";
        $xml .= "<sitemap><loc>$loc</loc><lastmod>" . current_time('c') . "</lastmod></sitemap>";
    }
    $xml .= '</sitemapindex>';

    return $xml;
}

/**
 * Render the language-specific sitemap
 */
function nuna_render_sitemap_by_language($lang_code)
{
    $pages = get_pages(['lang' => $lang_code]);
    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . "\n";
    $xml .= '        xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";

    foreach ($pages as $page) {
        $no_index = get_field('seo_no_index', $page->ID);
        if ($no_index)
            continue;

        $url = get_permalink($page);
        $lastmod = get_the_modified_time('c', $page);
        $priority = ($page->post_parent == 0 ? '1.0' : '0.8');

        $xml .= "  <url>\n";
        $xml .= "    <loc>{$url}</loc>\n";
        $xml .= "    <lastmod>{$lastmod}</lastmod>\n";
        $xml .= "    <changefreq>monthly</changefreq>\n";
        $xml .= "    <priority>{$priority}</priority>\n";

        $translations = apply_filters('wpml_get_element_translations', null, apply_filters('wpml_element_trid', null, $page->ID, 'post_page'));
        foreach ($translations as $trans) {
            if ($trans->element_id) {
                $hreflang = $trans->language_code;
                $href = get_permalink($trans->element_id);
                $xml .= "    <xhtml:link rel=\"alternate\" hreflang=\"{$hreflang}\" href=\"{$href}\" />\n";
            }
        }

        $xml .= "  </url>\n";
    }

    $xml .= '</urlset>';
    return $xml;
}
