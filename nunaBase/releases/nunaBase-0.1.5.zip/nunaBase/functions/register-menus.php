<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Register theme navigation menus.
 */
function nuna_register_nav_menu()
{
	register_nav_menus([
		'header' => __('Header', 'nunabase'),
		'footer' => __('Footer', 'nunabase'),
		'policies' => __('Policies', 'nunabase')
	]);
}

add_action('after_setup_theme', 'nuna_register_nav_menu', 0);