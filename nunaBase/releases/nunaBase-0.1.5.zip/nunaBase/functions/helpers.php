<?php
/**
 * Helpers for the NunaBase theme
 */

if (!defined('ABSPATH')) {
    exit;
}

function nuna_translate(string $key, string $lang = null): string
{
    static $strings = null;

    // Load once
    if ($strings === null) {
        $strings = require get_template_directory() . '/languages/strings.php';
    }

    // Detect language
    if ($lang === null) {
        $lang = get_locale(); // WordPress function, returns like 'en_US', 'es_ES'
        $lang = substr($lang, 0, 2); // Trim to 'en', 'es'
    }

    // If key exists
    if (isset($strings[$key])) {
        // If string exists in requested lang
        if (isset($strings[$key][$lang])) {
            return $strings[$key][$lang];
        }

        // Fallback to English
        if (isset($strings[$key]['en'])) {
            return $strings[$key]['en'];
        }
    }

    // If not found
    return $key;
}