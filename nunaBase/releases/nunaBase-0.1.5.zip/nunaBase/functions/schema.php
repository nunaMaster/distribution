<?php
if (!defined('ABSPATH'))
    exit;

/**
 * Render Hotel JSON-LD Schema based on ACF Options
 */
function nuna_render_hotel_schema_json()
{
    if (!is_front_page())
        return;

    $hotel_url = home_url('/');
    $schema = [
        "@context" => "https://schema.org",
        "@type" => "Hotel",
        "@id" => $hotel_url . "#hotel",
        "name" => get_bloginfo('name'),
        "description" => get_bloginfo('description'),
        "url" => $hotel_url,
        "telephone" => get_field('telephone', 'option'),
        "email" => get_field('email', 'option'),
        "address" => [
            "@type" => "PostalAddress",
            "streetAddress" => get_field('address', 'option'),
            "addressLocality" => get_field('locality', 'option'),
            "addressCountry" => get_field('country', 'option'),
        ],
        "priceRange" => "$$$",
        "checkInTime" => "15:00",
        "checkOutTime" => "11:00",
        "starRating" => [
            "@type" => "Rating",
            "ratingValue" => "5",
            "bestRating" => "5"
        ]
    ];

    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

add_action('wp_head', 'nuna_render_hotel_schema_json');