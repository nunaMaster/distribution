<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Render the Advantages section from ACF option page.
 *
 * Expected ACF fields:
 * - 'advantages_components': Flexible content (content + advantages blocks)
 * - 'advantages_classes': Extra CSS classes
 * - 'advantages_bg_image': Background image (ID)
 */

$components = get_field('advantages_components', 'option');

if (empty($components) || !is_array($components)) {
	return;
}

$classes = esc_attr(get_field('advantages_classes', 'option') ?: '');
$bg_image = get_field('advantages_bg_image', 'option');
$bg_url = $bg_image ? nuna_get_image_url($bg_image, 'full') : '';
$style = $bg_url ? ' style="--bg-image: url(' . esc_url($bg_url) . ');"' : '';
?>

<section class="s-advantages <?php echo $classes; ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php foreach ($components as $component) {
			$layout = $component['acf_fc_layout'] ?? '';

			if (!$layout)
				continue;

			switch ($layout) {
				case 'content':
					if (!empty($component['content'])) {
						echo '<div class="s-advantages__content">';
						c_content($component['content']);
						echo '</div>';
					}
					break;

				case 'advantages':
					if (!empty($component['advantages'])) {
						echo '<div class="s-advantages__list">';
						c_advantages($component['advantages']);
						echo '</div>';
					}
					break;
			}
		} ?>
	</div>
</section>