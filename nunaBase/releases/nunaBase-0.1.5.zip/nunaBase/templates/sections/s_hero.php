<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Output Hero Section with optional background media and flexible components.
 *
 * ACF Fields used:
 * - hero_components (Flexible Content)
 * - hero_bg_media (Image/Video/Slider)
 * - hero_classes (Custom CSS classes)
 * - booking_engine_id (from options)
 */

$components = get_field('hero_components');
$bg_media = get_field('hero_bg_media');

if (empty($components) && empty($bg_media['gallery']) && empty($bg_media['video'])) {
	return;
}

$section_id = 1;
$custom_classes = get_field('hero_classes') ?: '';
$show_booking_finder = get_field('show_booking_finder');
$booking_engine_id = get_field('booking_engine_id', 'option') ?: '';
$is_homepage = is_front_page() || is_home();

$section_classes = [
	's-hero',
	$is_homepage ? 's-hero--homepage' : '',
	$custom_classes,
];
?>

<section class="<?php echo esc_attr(implode(' ', array_filter($section_classes))); ?>">
	<?php if (!empty($bg_media['gallery']) || !empty($bg_media['video'])) {
		echo '<div class="s-hero__bg-media">';
		c_media($bg_media, [
			'draggable' => false,
			'wrapAround' => true,
			'autoPlay' => true,
			'pauseAutoPlayOnHover' => true,
			'prevNextButtons' => false,
			'pageDots' => false
		], $section_id, null, 'eager');
		echo '</div>';
	} ?>

	<div class="layout">
		<?php foreach ($components as $component) {
			$layout = $component['acf_fc_layout'] ?? '';

			if (!$layout)
				continue;

			switch ($layout) {
				case 'content':
					if (!empty($component['content'])) {
						echo '<div class="s-hero__content">';
						c_content($component['content']);
						echo '</div>';
					}
					break;

				case 'image':
					if (!empty($component['image'])) {
						echo '<div class="s-hero__image">';
						p_image($component['image']);
						echo '</div>';
					}
					break;
			}
		} ?>

		<?php if ($show_booking_finder && !empty($booking_engine_id)): ?>
			<div class="s-hero__booking-finder" data-mirai-component="finder" data-mobile="false"></div>
		<?php endif; ?>
	</div>
</section>