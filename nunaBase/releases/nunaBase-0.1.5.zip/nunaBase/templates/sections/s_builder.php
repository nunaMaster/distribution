<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Builder Section Renderer
 *
 * Outputs flexible layout components (content, media, blocks) inside a section.
 *
 * @param array $section {
 *     The configuration array for this section.
 *
 *     @type array  $builder_components  Flexible content components: content, media, blocks.
 *     @type string $classes             Additional classes for <section>.
 *     @type int    $builder_bg_image    Attachment ID for section background image.
 *     @type int    $builder_max_images  Max image count for media sliders.
 * }
 */

$components = $section['builder_components'] ?? [];

if (empty($components) || !is_array($components)) {
	return;
}

$classes = $section['classes'] ?? '';
$max_images = $section['builder_max_images'] ?? null;
$bg_image_id = $section['builder_bg_image'] ?? null;
$bg_url = $bg_image_id ? nuna_get_image_url($bg_image_id, 'full') : '';
$style = $bg_url ? ' style="--bg-image: url(' . esc_url($bg_url) . ');"' : '';
?>

<section class="s-builder <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php foreach ($components as $component) {
			$layout = $component['acf_fc_layout'] ?? '';
			if (!$layout)
				continue;

			switch ($layout) {
				case 'content':
					if (!empty($component['content'])) {
						echo '<div class="s-builder__content">';
						c_content($component['content']);
						echo '</div>';
					}
					break;

				case 'media':
					$media = build_media_array($component);
					if (!empty($media)) {
						echo '<div class="s-builder__media">';
						c_media($media, [
							'draggable' => false,
							'wrapAround' => true,
							'pageDots' => false
						], "section-gallery-{$section_id}", $max_images);
						echo '</div>';
					}
					break;

				case 'blocks':
					if (!empty($component['blocks'])): ?>
						<div class="s-builder__blocks">
							<?php foreach ($component['blocks'] as $block_key => $block):
								$block_components = $block['components'] ?? [];
								if (empty($block_components))
									continue;

								$block_bg_id = $block['bg_image'] ?? null;
								$block_bg_url = $block_bg_id ? nuna_get_image_url($block_bg_id, 'medium') : '';
								$block_style = $block_bg_url ? ' style="--block-bg-image: url(' . esc_url($block_bg_url) . ');"' : '';
								?>
								<div class="s-builder__block" <?php echo $block_style; ?>>
									<?php foreach ($block_components as $block_component) {
										$block_layout = $block_component['acf_fc_layout'] ?? '';
										if (!$block_layout)
											continue;

										switch ($block_layout) {
											case 'content':
												if (!empty($block_component['content'])) {
													echo '<div class="s-builder__block-content">';
													c_content($block_component['content']);
													echo '</div>';
												}
												break;

											case 'media':
												$block_media = build_media_array($block_component);
												if (!empty($block_media)) {
													echo '<div class="s-builder__block-media">';
													c_media($block_media, [
														'draggable' => false,
														'wrapAround' => true,
														'pageDots' => false
													], "block-gallery-{$block_key}", $max_images);
													echo '</div>';
												}
												break;
										}
									} ?>
								</div>
							<?php endforeach; ?>
						</div>
					<?php endif;
					break;
			}
		} ?>
	</div>
</section>