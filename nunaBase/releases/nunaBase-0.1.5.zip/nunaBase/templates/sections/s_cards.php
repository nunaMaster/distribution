<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Cards Section Renderer
 *
 * Renders a section displaying cards and optional introductory content.
 *
 * @param array $section {
 *     Section configuration.
 *
 *     @type array  $cards_components        Flexible layout components: 'content', 'cards'.
 *     @type string $classes                 Additional CSS class names for styling the section.
 *     @type int    $cards_bg_image          Background image attachment ID.
 * }
 */

$components = $section['cards_components'] ?? [];

if (empty($components) || !is_array($components)) {
	return;
}

$classes = $section['classes'] ?? '';
$bg_image_id = $section['cards_bg_image'] ?? null;
$bg_url = $bg_image_id ? nuna_get_image_url($bg_image_id, 'full') : '';
$style = $bg_url ? ' style="--bg-image: url(' . esc_url($bg_url) . ');"' : '';
?>

<section class="s-cards <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php foreach ($components as $component) {
			$layout = $component['acf_fc_layout'] ?? '';
			if (!$layout)
				continue;

			switch ($layout) {
				case 'content':
					if (!empty($component['content'])) {
						echo '<div class="s-cards__content">';
						c_content($component['content']);
						echo '</div>';
					}
					break;

				case 'cards':
					if (!empty($component['cards'])) {
						$cards_layout = $component['cards_layout'];

						echo '<div class="s-cards__list">';
						c_cards($component['cards'], $cards_layout);
						echo '</div>';
					}
					break;
			}
		} ?>
	</div>
</section>