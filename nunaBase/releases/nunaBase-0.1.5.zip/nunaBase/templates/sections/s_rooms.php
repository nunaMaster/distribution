<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Rooms Section Renderer
 *
 * Renders a section displaying rooms and optional introductory content.
 *
 * @param array $section {
 *     Section configuration.
 *
 *     @type array  $rooms_components        Flexible layout components: 'content', 'rooms'.
 *     @type string $classes                 Additional CSS class names for styling the section.
 *     @type int    $rooms_bg_image          Background image attachment ID.
 * }
 */

$components = $section['rooms_components'] ?? [];

if (empty($components) || !is_array($components)) {
	return;
}

$classes = $section['classes'] ?? '';
$bg_image_id = $section['rooms_bg_image'] ?? null;
$bg_url = $bg_image_id ? nuna_get_image_url($bg_image_id, 'full') : '';
$style = $bg_url ? ' style="--bg-image: url(' . esc_url($bg_url) . ');"' : '';
?>

<section class="s-rooms <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php foreach ($components as $component) {
			$layout = $component['acf_fc_layout'] ?? '';
			if (!$layout)
				continue;

			switch ($layout) {
				case 'content':
					if (!empty($component['content'])) {
						echo '<div class="s-rooms__content">';
						c_content($component['content']);
						echo '</div>';
					}
					break;

				case 'rooms':
					if (!empty($component['rooms'])) {
						$rooms_layout = $component['rooms_layout'];
						$show_view_button = $component['rooms_show_view_button'];

						echo '<div class="s-rooms__list">';
						c_rooms($component['rooms'], $rooms_layout, $show_view_button);
						echo '</div>';
					}
					break;
			}
		} ?>
	</div>
</section>