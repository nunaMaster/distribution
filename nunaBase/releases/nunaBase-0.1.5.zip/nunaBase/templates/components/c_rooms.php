<?php
function c_rooms($rooms, $layout = 'carousel', $show_view_button = true)
{
	if (empty($rooms) || !is_array($rooms))
		return;

	$room_query = new WP_Query([
		'post_type' => 'room',
		'posts_per_page' => -1,
		'post__in' => $rooms,
		'orderby' => 'post__in',
	]);

	if (!$room_query->have_posts())
		return;

	$is_carousel = $layout === 'carousel';
	$list_class = 'c-rooms c-rooms--' . esc_attr($layout);
	$carousel_attrs = $is_carousel
		? ' data-flickity=\'' . wp_json_encode([
			'cellAlign' => 'left',
			'contain' => true,
			'pageDots' => false,
		]) . '\''
		: '';

	echo "<div class=\"$list_class\" $carousel_attrs>";

	while ($room_query->have_posts()):
		$room_query->the_post();
		$room_id = get_the_ID();
		$title = get_the_title();
		$content = get_the_content();
		$gallery = get_field('gallery');
		$has_thumb = has_post_thumbnail();
		?>

		<?php if ($is_carousel): ?>
			<div class="carousel-room"><?php endif; ?>

			<article <?php post_class('c-room c-card'); ?>>
				<?php echo render_room_gallery_or_thumb($gallery, $room_id, $has_thumb); ?>

				<div class="c-room__content">
					<div class="c-room__title p-title p-title--sm"><?php echo esc_html($title); ?></div>

					<?php if (!empty($content)): ?>
						<div class="c-room__description default-style">
							<?php echo apply_filters('the_content', $content); ?>
						</div>
					<?php endif; ?>

					<?php if ($show_view_button): ?>
						<button class="c-room__cta p-button p-button--secondary"
							data-show-modal="room-details-<?php echo esc_attr($room_id); ?>">
							<?php echo nuna_translate('view_details'); ?>
						</button>
					<?php endif; ?>
				</div>
			</article>

			<?php if ($is_carousel): ?>
			</div><?php endif; ?>
	<?php endwhile; ?>
	</div>
	<?php wp_reset_postdata(); ?>

	<?php
	// MODALS
	while ($room_query->have_posts()):
		$room_query->the_post();
		$room_id = get_the_ID();

		$header = '<div class="c-room__details-title p-title p-title--sm">' . esc_html(get_the_title()) . '</div>';
		$body = render_room_modal_body($room_id);

		c_modal("room-details-{$room_id}", $header, $body);
	endwhile;
	wp_reset_postdata();
}

function render_room_gallery_or_thumb($gallery, $room_id, $has_thumb)
{
	ob_start();
	if (!empty($gallery)) {
		echo '<div class="c-room__gallery-wrapper c-card__gallery-wrapper">';
		echo '<div class="c-room__gallery c-card__gallery" data-flickity=\'{"draggable": false, "wrapAround": true, "pageDots": false}\'>';
		foreach ($gallery as $image) {
			$img_url = esc_url(wp_get_attachment_image_url($image['ID'], 'full'));
			echo "<div class='carousel-image'>
					<a href='$img_url' data-fancybox='room-gallery-{$room_id}'>";
			p_image($image['ID']);
			echo "</a></div>";
		}
		echo '</div></div>';
	} elseif ($has_thumb) {
		echo '<div class="c-room__image">';
		the_post_thumbnail('medium_large');
		echo '</div>';
	}
	return ob_get_clean();
}

function render_room_modal_body($room_id)
{
	$room_size = get_field('room_size', $room_id);
	$max_occupancy = get_field('max_occupancy', $room_id);
	$bed_type = get_field('bed_type', $room_id);
	$view = get_field('view', $room_id);
	$amenities = get_field('amenities', $room_id);
	$content = get_the_content();
	$gallery = get_field('gallery', $room_id);
	$has_thumb = has_post_thumbnail($room_id);

	ob_start();
	?>

	<div class="c-room__details-body">
		<?php echo render_room_gallery_or_thumb($gallery, $room_id, $has_thumb); ?>

		<div class="c-room__content">
			<div class="c-room__info">
				<?php if ($room_size): ?>
					<div class="c-room__info-item"><?php p_icon('room-size'); ?><span><?php echo esc_html($room_size); ?>
							m²</span></div>
				<?php endif; ?>
				<?php if ($max_occupancy): ?>
					<div class="c-room__info-item">
						<?php p_icon('people'); ?><span><?php echo esc_html($max_occupancy); ?></span>
					</div>
				<?php endif; ?>
				<?php if ($bed_type): ?>
					<div class="c-room__info-item"><?php p_icon('bed'); ?><span><?php echo esc_html($bed_type); ?></span></div>
				<?php endif; ?>
				<?php if ($view): ?>
					<div class="c-room__info-item"><?php p_icon('landscape'); ?><span><?php echo esc_html($view); ?></span>
					</div>
				<?php endif; ?>
			</div>

			<?php if (!empty($amenities)): ?>
				<div class="c-room__amenities">
					<div class="c-room__amenities-title"><?php echo nuna_translate('amenities'); ?></div>
					<?php foreach ($amenities as $item): ?>
						<div class="c-room__amenity">
							<?php p_icon(strtolower(str_replace(' ', '-', $item))); ?>
							<span><?php echo esc_html($item); ?></span>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ($content): ?>
				<div class="c-room__details-description-wrapper">
					<div class="c-room__details-description-title"><?php echo nuna_translate('description'); ?></div>
					<div class="c-room__details-description default-style"><?php echo apply_filters('the_content', $content); ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>

	<?php
	return ob_get_clean();
}