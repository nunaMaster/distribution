<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Render a group of cards.
 *
 * @param array  $cards        List of card data. Each card can include:
 *                             - 'image' (int): Image attachment ID.
 *                             - 'gallery' (array): List of attachment IDs for a gallery.
 *                             - 'content' (array): Content array (title, desc, button).
 * @param string $layout Layout type: 'carousel' or 'grid' (default: 'carousel').
 */
function c_cards($cards, $layout = 'carousel')
{
	if (empty($cards) || !is_array($cards)) {
		return;
	}

	$is_carousel = ($layout === 'carousel');
	$list_class = 'c-cards c-cards--' . esc_attr($layout);
	$carousel_attrs = $is_carousel
		? ' data-flickity=\'' . wp_json_encode([
			'cellAlign' => 'left',
			'contain' => true,
			'pageDots' => false,
		]) . '\''
		: '';
	?>
	<div class="<?php echo $list_class; ?>" <?php echo $carousel_attrs; ?>>
		<?php foreach ($cards as $card_id => $card): ?>
			<?php
			$image = $card['image'] ?? null;
			$gallery = $card['gallery'] ?? [];
			$content = $card['content'] ?? null;

			if ($is_carousel) {
				echo '<div class="carousel-card">';
			}
			?>

			<article class="c-card">
				<?php if (!empty($gallery) && !empty($image)): ?>
					<div class="c-card__media">
					<?php endif; ?>

					<?php
					if (!empty($gallery)):
						$is_single = count($gallery) === 1 ? 'c-card__gallery--single' : '';
						?>
						<div class="c-card__gallery-wrapper">
							<div class="c-card__gallery <?php echo esc_attr($is_single); ?>"
								data-flickity='{ "draggable": false, "pageDots": false }'>
								<?php foreach ($gallery as $gallery_image): ?>
									<div class="carousel-image">
										<a href="<?php echo esc_url(wp_get_attachment_image_url($gallery_image, 'full')); ?>"
											data-fancybox="card-gallery-<?php echo esc_attr($card_id); ?>">
											<?php p_image($gallery_image); ?>
										</a>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>

					<?php if (!empty($image)): ?>
						<div class="c-card__image">
							<?php p_image($image); ?>
						</div>
					<?php endif; ?>

					<?php if (!empty($gallery) && !empty($image)): ?>
					</div>
				<?php endif; ?>

				<?php if (!empty($content)): ?>
					<div class="c-card__content">
						<?php c_content($content); ?>
					</div>
				<?php endif; ?>
			</article>

			<?php
			if ($is_carousel) {
				echo '</div>';
			}
			?>
		<?php endforeach; ?>
	</div>
	<?php
}