<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Render the mobile action bar component.
 *
 * @param string $telephone     Phone number to display.
 * @param array  $social_media  Array of social media items (associative: 'platform', 'url').
 * @param string $button_label  Label for the booking button.
 */
function c_action_bar($telephone = '', $social_media = [], $button_label = '')
{
	// Bail early if there's nothing to show
	if (empty($telephone) && empty($social_media) && empty($button_label)) {
		return;
	}
	?>
	<div class="mobile-action-bar c-action-bar">
		<div class="c-action-bar__contact">
			<button class="contact__icon p-button p-button--secondary" aria-expanded="false" aria-controls="contact-list"
				aria-label="Toggle contact options">
				<?php p_icon('concierge-bell'); ?>
			</button>

			<ul class="contact__list" id="contact-list" hidden>
				<?php if (!empty($telephone)): ?>
					<li class="contact__item">
						<a class="p-button p-button--secondary" href="tel:<?php echo esc_attr($telephone); ?>">
							<?php echo esc_html($telephone); ?>
						</a>
					</li>
				<?php endif; ?>

				<?php if (!empty($social_media)): ?>
					<?php foreach ($social_media as $social):
						$platform = isset($social['platform']) ? strtolower(trim($social['platform'])) : '';
						$url = isset($social['url']) ? esc_url($social['url']) : '';
						$name = isset($social['platform']) ? esc_html($social['platform']) : '';

						if ($platform === 'whatsapp' && $url):
							?>
							<li class="contact__item">
								<a class="p-button p-button--secondary" href="<?php echo $url; ?>" target="_blank"
									rel="noopener noreferrer">
									<?php echo esc_html($name); ?>
								</a>
							</li>
							<?php
						endif;
					endforeach; ?>
				<?php endif; ?>
			</ul>
		</div>

		<?php if (!empty($button_label)): ?>
			<button class="p-button" data-show-modal="header-overlay-panel" data-panel-toggle="book">
				<?php echo esc_html($button_label); ?>
			</button>
		<?php endif; ?>
	</div>
	<?php
}