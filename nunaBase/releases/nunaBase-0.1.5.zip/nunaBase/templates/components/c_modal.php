<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render a modal component with optional header, body, and footer.
 *
 * @param string $modal_id       Unique ID of the modal.
 * @param string $modal_header   HTML content for the modal header.
 * @param string $modal_body     HTML content for the modal body.
 * @param string $modal_footer   HTML content for the modal footer.
 */

function c_modal($modal_id, $modal_header = '', $modal_body = '', $modal_footer = '')
{
    if (empty($modal_id)) {
        return;
    }
    ?>
    <div class="c-modal" id="<?php echo esc_attr($modal_id); ?>" role="dialog" aria-modal="true" tabindex="-1"
        aria-hidden="true">
        <div class="c-modal__content">
            <div class="c-modal__header">
                <?php echo $modal_header; ?>
                <button class="c-modal__close-button" data-close-modal aria-label="Close modal">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M480-451.69 270.15-241.85q-5.61 5.62-13.77 6-8.15.39-14.53-6-6.39-6.38-6.39-14.15 0-7.77 6.39-14.15L451.69-480 241.85-689.85q-5.62-5.61-6-13.77-.39-8.15 6-14.53 6.38-6.39 14.15-6.39 7.77 0 14.15 6.39L480-508.31l209.85-209.84q5.61-5.62 13.77-6 8.15-.39 14.53 6 6.39 6.38 6.39 14.15 0 7.77-6.39 14.15L508.31-480l209.84 209.85q5.62 5.61 6 13.77.39 8.15-6 14.53-6.38 6.39-14.15 6.39-7.77 0-14.15-6.39L480-451.69Z" />
                    </svg>
                </button>
            </div>
            <?php if (!empty($modal_body)): ?>
                <div class="c-modal__body">
                    <?php echo $modal_body; ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($modal_footer)): ?>
                <div class="c-modal__footer">
                    <?php echo $modal_footer; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}