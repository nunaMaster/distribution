<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render an inline SVG icon from the theme directory.
 *
 * @param string $name The icon file name (without extension).
 */
function p_icon($name)
{
    if (!$name) {
        return;
    }

    $icon_style = get_theme_mod('icon_style', 'solid');
    $icon_path = get_template_directory() . "/dist/assets/icons/{$icon_style}/{$name}.svg";

    if (file_exists($icon_path)) {
        $icon = file_get_contents($icon_path);
        echo '<span class="p-icon" aria-hidden="true">' . $icon . '</span>';
    }
}