<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render a responsive, accessible image with optional lightbox and caption.
 *
 * @param int  $image       The attachment ID from ACF.
 * @param bool $lightbox    Whether to enable lightbox (default: false).
 * @param null|string|int $gallery_id Optional group ID for fancybox gallery.
 */
function p_image($image, $lightbox = false, $gallery_id = null, $loading = 'lazy')
{
    if (empty($image)) {
        return;
    }

    // Responsive sizes definition
    $sizes = "(max-width: 480px) 100vw, (max-width: 768px) 100vw, (max-width: 1024px) 90vw, (max-width: 1440px) 80vw, 1440px";

    // Get alt text or fallback to title
    $alt = get_post_meta($image, '_wp_attachment_image_alt', true);
    if (!$alt) {
        $alt = get_the_title($image);
    }

    // Image attributes
    $attributes = [
        'sizes' => esc_attr($sizes),
        'loading' => $loading === 'eager' ? 'eager' : 'lazy',
        'decoding' => 'async',
    ];

    // Optional caption
    $caption = wp_get_attachment_caption($image);

    // Lightbox setup
    $lightbox_url = $lightbox ? esc_url(wp_get_attachment_image_url($image, 'full')) : '';
    $data_fancybox = $gallery_id ? ' data-fancybox="gallery-' . esc_attr($gallery_id) . '"' : '';
    ?>
    <figure class="p-image">
        <div class="p-image__image">
            <?php if ($lightbox_url): ?>
                <a href="<?php echo $lightbox_url; ?>" <?php echo $data_fancybox; ?> aria-label="<?php echo esc_attr($alt); ?>">
                    <?php echo wp_get_attachment_image($image, 'full', false, $attributes); ?>
                </a>
            <?php else: ?>
                <?php echo wp_get_attachment_image($image, 'full', false, $attributes); ?>
            <?php endif; ?>
        </div>

        <?php if ($caption): ?>
            <figcaption class="p-image__caption">
                <?php echo wp_kses_post($caption); ?>
            </figcaption>
        <?php endif; ?>
    </figure>
    <?php
}