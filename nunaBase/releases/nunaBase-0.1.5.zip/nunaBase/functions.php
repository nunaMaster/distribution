<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

$function_files = [
	// Utility functions
	'helpers',

	// Core WordPress enhancements
	'clean-wordpress',
	'theme-support',
	'theme-images',
	'image-optimizer',
	'enqueue-assets',

	// Customization and templates
	'customizer',
	'autoload-templates',
	'register-menus',
	'menu-walker',
	'shortcodes',

	// Plugins and integrations
	'acf-fields',
	'seo',
	'sitemap',
	'schema',
	'wpml',
	'update-checker',
];

foreach ($function_files as $file) {
	$file_path = get_template_directory() . "/functions/{$file}.php";

	if (file_exists($file_path)) {
		require_once $file_path;
	} else {
		error_log("Missing function file: {$file_path}");
	}
}