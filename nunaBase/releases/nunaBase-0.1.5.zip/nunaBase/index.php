<?php
/**
 * The main template file
 *
 * Fallback template with dev-style preview: fonts, colors, spacing, etc.
 *
 * @package YourTheme
 */

if (!defined('ABSPATH')) {
	exit;
}

get_header();
?>

<section class="content-wrap" style="max-width: 720px; margin: 0 auto;">
	<div class="layout" style="gap: calc(var(--space) * 0.5);">
		<h1
			style="font-size: var(--p-title-md); line-height: var(--p-title-line-height); font-family: var(--font-heading); font-weight: var(--font-weight-heading);">
			🎨 Style Guide Preview
		</h1>
		<p style="font-family: var(--font); line-height: var(--line-height);">This is your fallback
			<code>index.php</code> template.
		</p>

		<hr style="margin: 1rem 0;">

		<h2>🖌️ Brand Colors</h2>
		<div style="display: flex; flex-wrap: wrap; gap: 1rem;">
			<?php
			$colors = [
				'brand',
				'brand-alt',
				'accent',
			];
			foreach ($colors as $color) {
				echo '<div style="flex: 1 1 120px;">';
				echo '<div style="height: 50px; background: var(--color-' . esc_attr($color) . '); border: 1px solid #ccc;"></div>';
				echo '<small>--color-' . esc_html($color) . '</small>';
				echo '</div>';
			}
			?>
		</div>

		<hr style="margin: 1rem 0;">

		<h2>🔤 Font Samples</h2>
		<p style="font-family: var(--font-heading); font-weight: var(--font-weight-heading);">Heading Font: The quick
			brown fox</p>
		<p style="font-family: var(--font);">Body Font: The quick brown fox</p>

		<hr style="margin: 1rem 0;">

		<h2>📏 Title Sizes</h2>
		<p
			style="font-size: var(--p-title-lg); line-height: var(--p-title-line-height); font-family: var(--font-heading);">
			Large Title</p>
		<p
			style="font-size: var(--p-title-md); line-height: var(--p-title-line-height); font-family: var(--font-heading);">
			Medium Title</p>
		<p
			style="font-size: var(--p-title-sm); line-height: var(--p-title-line-height); font-family: var(--font-heading);">
			Small Title</p>
	</div>
</section>

<?php get_footer(); ?>