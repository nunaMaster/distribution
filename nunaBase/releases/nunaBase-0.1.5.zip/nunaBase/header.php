<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <!-- Basic Meta -->
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- SEO Meta -->
    <?php nuna_render_seo_meta(); ?>

    <!-- Favicon & Theme Color -->
    <link rel="icon" href="<?php echo esc_url(get_template_directory_uri() . '/favicon.ico'); ?>" type="image/x-icon">
    <meta name="theme-color" content="#ffffff">

    <!-- Booking Engine CSS -->
    <?php
    $booking_engine_id = get_field('booking_engine_id', 'option');
    $book_cta_label = get_field('book_cta_label', 'option');
    ?>
    <?php if (!empty($booking_engine_id)): ?>
        <link rel="preload" as="style" href="https://static.mirai.com/core/index.css"
            onload="this.onload=null;this.rel='stylesheet'" />
    <?php endif; ?>

    <!-- WordPress Hooks -->
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <?php if (!empty($booking_engine_id)): ?>
        <div data-mirai-id="<?php echo esc_attr($booking_engine_id); ?>"></div>
    <?php endif; ?>

    <?php
    // Cache menu and theme settings
    $header_menu = wp_nav_menu([
        'theme_location' => 'header',
        'container' => false,
        'menu_id' => '',
        'echo' => false,
        'fallback_cb' => false
    ]);

    $header_layout = get_theme_mod('header_layout', 'default');

    // Header layout classes map
    $header_classes = [
        'logo_left_menu_center' => 'c-header--menu-center',
        'logo_left_hamburger_left' => 'c-header--hamburger c-header--hamburger-left',
        'logo_left_hamburger_right' => 'c-header--hamburger c-header--hamburger-right',
        'logo_center_menu_split' => 'c-header--logo-center c-header--menu-split',
        'logo_center_hamburger_left' => 'c-header--logo-center c-header--hamburger c-header--hamburger-left',
        'logo_center_hamburger_right' => 'c-header--logo-center c-header--hamburger c-header--hamburger-right',
    ];

    $show_header_cta = get_theme_mod('show_header_cta', false);

    $header_class = $header_classes[$header_layout] ?? '';
    $site_name = get_bloginfo('name');
    $home_url = esc_url(home_url());
    ?>

    <header class="c-header <?php echo esc_attr($header_class); ?>">
        <div class="c-header__container">
            <div class="c-header__logo">
                <?php if (has_custom_logo()) {
                    the_custom_logo();
                } else { ?>
                    <a class="c-header__logo-link" href="<?php echo $home_url; ?>" rel="home">
                        <h1><?php echo esc_html($site_name); ?></h1>
                    </a>
                <?php } ?>
            </div>

            <?php if ($header_menu): ?>
                <nav class="c-header__nav" aria-label="Header Menu">
                    <?php echo $header_menu ?>
                </nav>
            <?php endif; ?>

            <button class="c-header__hamburger" data-show-modal="header-overlay-panel" data-panel-toggle="menu"
                aria-label="<?php esc_attr_e('Toggle menu', 'nunabase'); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" fill="currentColor">
                    <path
                        d="M180-269.23q-8.5 0-14.25-5.76T160-289.26q0-8.51 5.75-14.24t14.25-5.73h600q8.5 0 14.25 5.76 5.75 5.75 5.75 14.27 0 8.51-5.75 14.24T780-269.23H180ZM180-460q-8.5 0-14.25-5.76T160-480.03q0-8.51 5.75-14.24T180-500h600q8.5 0 14.25 5.76t5.75 14.27q0 8.51-5.75 14.24T780-460H180Zm0-190.77q-8.5 0-14.25-5.76-5.75-5.75-5.75-14.27 0-8.51 5.75-14.24t14.25-5.73h600q8.5 0 14.25 5.76t5.75 14.27q0 8.51-5.75 14.24T780-650.77H180Z" />
                </svg>
            </button>

            <?php if ($show_header_cta && $book_cta_label): ?>
                <button class="c-header__cta p-button" data-show-modal="header-overlay-panel" data-panel-toggle="book">
                    <?php echo esc_html($book_cta_label); ?>
                </button>
            <?php endif; ?>
        </div>

        <?php
        /** HEADER PANEL COMPONENTS **/

        // Panel Header
        ob_start(); ?>
        <div class="panel__logo c-header__logo">
            <?php if (has_custom_logo()) {
                the_custom_logo();
            } else { ?>
                <a class="panel__logo-link" href="<?php echo $home_url; ?>" rel="home">
                    <?php echo esc_html($site_name); ?>
                </a>
            <?php } ?>
        </div>
        <button class="panel__cta-booking p-button p-button--secondary" data-panel-toggle="toggle">
            <?php esc_html($book_cta_label); ?>
        </button>

        <?php
        $panel_header = ob_get_clean();

        // Panel Body
        ob_start();
        ?>
        <div class="c-modal__body-wrapper" data-state="menu">
            <?php
            $panel_menu = wp_nav_menu([
                'theme_location' => 'header',
                'container' => false,
                'menu_id' => '',
                'echo' => false,
                'fallback_cb' => false,
                'walker' => new Walker_Nav_Menu_With_Description(),
            ]);

            if ($panel_menu): ?>
                <nav class="panel__menu">
                    <?php echo $panel_menu ?>
                </nav>
            <?php endif;

            if (!empty($booking_engine_id)): ?>
                <div class="panel__booking">
                    <div data-mirai-component="finder"></div>
                    <?php
                    $advantages_components = get_field('advantages_components', 'option');
                    $advantages = [];

                    if (!empty($advantages_components) && is_array($advantages_components)) {
                        foreach ($advantages_components as $component) {
                            if (($component['acf_fc_layout'] ?? '') === 'advantages') {
                                $advantages = $component['advantages'] ?? [];
                                break;
                            }
                        }
                    }

                    if ($advantages) {
                        c_advantages($advantages);
                    }
                    ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        $panel_body = ob_get_clean();

        // Panel Footer
        ob_start();

        echo do_shortcode('[nuna_wpml_language_selector class="panel__languages"]');

        $telephone = get_field('telephone', 'option');
        $email = get_field('email', 'option');
        ?>

        <div class="panel__contact">
            <?php if ($telephone): ?>
                <a class="panel__contact-link" href="tel:<?php echo esc_attr($telephone); ?>">
                    <?php p_icon('phone'); ?>
                    <span class="label">
                        <?php echo esc_html($telephone); ?>
                    </span>
                </a>
            <?php endif; ?>

            <?php if ($email): ?>
                <a class="panel__contact-link" href="mailto:<?php echo esc_attr($email); ?>">
                    <?php p_icon('mail'); ?>
                    <span class="label">
                        <?php echo esc_html($email); ?>
                    </span>
                </a>
            <?php endif; ?>
        </div>

        <?php $panel_footer = ob_get_clean();

        // Render Modal
        c_modal('header-overlay-panel', $panel_header, $panel_body, $panel_footer);
        ?>
    </header>

    <main>