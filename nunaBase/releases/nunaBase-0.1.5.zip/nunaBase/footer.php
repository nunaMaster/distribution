</main>

<footer class="c-footer">
    <div class="c-footer__top">
        <?php
        $site_name = get_bloginfo('name');
        $home_url = home_url('/');

        $hotel_chain = get_field('hotel_chain', 'option');
        $chain_name = get_field('chain_name', 'option');
        $chain_hotels = get_field('chain_hotels', 'option');

        $footer_logo_id = get_theme_mod('footer_logo');

        $telephone = get_field('telephone', 'option');
        $email = get_field('email', 'option');
        $address = get_field('address', 'option');
        $locality = get_field('locality', 'option');
        $country = get_field('country', 'option');
        $social_media = get_field('social_media', 'option');
        ?>

        <?php if ($hotel_chain): ?>
            <div class="c-footer__chain c-footer__top-item">
                <?php if ($chain_name): ?>
                    <?php p_title('div', $chain_name, '3'); ?>
                <?php endif; ?>

                <?php if (!empty($chain_hotels)): ?>
                    <div class="c-footer__chain-hotels">
                        <?php foreach ($chain_hotels as $hotel): ?>
                            <?php
                            $image = esc_html($hotel['image']);
                            $name = esc_html($hotel['content']['name']);
                            $description = wp_kses_post($hotel['content']['description']);
                            $url = esc_url($hotel['content']['url']);
                            ?>
                            <div class="c-footer__hotel">
                                <a class="c-footer__hotel-link" href="<?php echo $url; ?>" target="_blank"
                                    rel="noopener noreferrer">
                                    <?php if ($image): ?>
                                        <?php p_image($image); ?>
                                    <?php endif; ?>
                                    <div class="c-footer__hotel-content">
                                        <?php if ($name): ?>
                                            <div class="c-footer__hotel-name">
                                                <?php echo $name; ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($description): ?>
                                            <div class="c-footer__hotel-description">
                                                <?php echo $description; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (has_nav_menu('footer')): ?>
            <nav class="c-footer__nav c-footer__top-item" aria-label="<?php esc_attr_e('Footer menu', 'nunabase'); ?>">
                <?php
                p_title('div', wp_get_nav_menu_name('footer'), '3');

                wp_nav_menu([
                    'theme_location' => 'footer',
                    'container' => false,
                    'menu_id' => '',
                    'fallback_cb' => false
                ]); ?>
            </nav>
        <?php endif; ?>

        <div class="c-footer__info c-footer__top-item">
            <?php if ($telephone || $email || $address || $locality || $country): ?>
                <?php p_title('div', nuna_translate('contact'), '3'); ?>
            <?php endif; ?>

            <div class="info__container">
                <div class="info__logo">
                    <?php if ($footer_logo_id): ?>
                        <a class="info__logo-link" href="<?php echo esc_url($home_url); ?>" rel="home">
                            <?php echo wp_get_attachment_image($footer_logo_id, 'medium'); ?>
                        </a>
                    <?php elseif (has_custom_logo()): ?>
                        <?php echo get_custom_logo(); ?>
                    <?php else: ?>
                        <a class="info__logo-link" href="<?php echo esc_url($home_url); ?>" rel="home">
                            <?php echo esc_html($site_name); ?>
                        </a>
                    <?php endif; ?>
                </div>

                <div class="info__content">
                    <div class="info__contact">
                        <div class="info__hotel-name">
                            <?php echo esc_html($site_name); ?>
                        </div>
                        <?php if ($telephone): ?>
                            <div class="info__telephone">
                                <a href="tel:<?php echo esc_html($telephone); ?>">
                                    <?php echo esc_html($telephone); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        <?php if ($email): ?>
                            <div class="info__email">
                                <a href="mailto:<?php echo esc_html($email); ?>">
                                    <?php echo esc_html($email); ?>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if ($address || $locality || $country): ?>
                            <div class="info__location">
                                <?php if ($address): ?>
                                    <span class="info__address">
                                        <?php echo esc_html($address); ?>
                                    </span>
                                <?php endif; ?>
                                <?php if ($locality): ?>
                                    <span class="info__locality">
                                        <?php echo esc_html($locality); ?>
                                    </span>
                                <?php endif; ?>
                                <?php if ($country): ?>
                                    <span class="info__country">
                                        <?php echo esc_html($country); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($social_media)): ?>
                        <ul class="info__socials">
                            <?php foreach ($social_media as $social): ?>
                                <li class="info__social">
                                    <a href="<?php echo esc_url($social['url']); ?>" target="_blank" rel="noopener noreferrer"
                                        aria-label="<?php echo esc_attr($social['platform']); ?>">
                                        <?php p_icon(strtolower($social['platform'])); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


    <div class="c-footer__bottom">
        <?php echo do_shortcode('[nuna_wpml_language_selector class="c-footer__languages"]') ?>

        <?php
        $copyright_year = date('Y');
        $copyright_url = esc_url($home_url);
        $copyright_url_label = $site_name;

        $chain_copyright = get_field('chain_copyright', 'option');

        if (is_array($chain_copyright) && !empty($chain_copyright['url']) && !empty($chain_copyright['title'])) {
            $copyright_url = esc_url($chain_copyright['url']);
            $copyright_url_label = trim($chain_copyright['title']);
        }
        ?>

        <div class="c-footer__copyright">
            &copy; <?php echo esc_html($copyright_year); ?> By <a href="<?php echo $copyright_url; ?>" rel="home"
                target="_blank"><?php echo esc_html($copyright_url_label); ?></a>
        </div>

        <?php if (has_nav_menu('policies')): ?>
            <nav class="c-footer__policies" aria-label="<?php esc_attr_e('Legal and policy links', 'nunabase'); ?>">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'policies',
                    'container' => false,
                    'menu_id' => '',
                    'echo' => true,
                    'fallback_cb' => false
                ));
                ?>
            </nav>
        <?php endif; ?>
    </div>
</footer>

<?php
$book_cta_label = get_field('book_cta_label', 'option');
c_action_bar($telephone, $social_media, $book_cta_label);
?>

<script>
    window.__translations = <?php echo json_encode([
        'book' => $book_cta_label ?: 'Book',
        'menu' => nuna_translate('menu'),
    ]); ?>;
</script>

<?php
$booking_engine_id = get_field('booking_engine_id', 'option');
if (!empty($booking_engine_id)):
    ?>
    <script async type="module" defer src="https://static.mirai.com/core/index.js"></script>
    <?php
endif;
wp_footer();
?>

</body>

</html>