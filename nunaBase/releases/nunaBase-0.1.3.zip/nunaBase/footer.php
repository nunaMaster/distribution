</main>

<footer class="c-footer">
    <div class="layout c-footer__top">
        <?php
        $hotel_chain = get_field('hotel_chain', 'option');
        $chain_name = get_field('chain_name', 'option');
        $chain_hotels = get_field('chain_hotels', 'option');
        $footer_logo_id = get_theme_mod('footer_logo');
        $telephone = get_field('telephone', 'option');
        $email = get_field('email', 'option');
        $address = get_field('address', 'option');
        $locality = get_field('locality', 'option');
        $country = get_field('country', 'option');
        $social_media = get_field('social_media', 'option');
        ?>

        <?php if ($hotel_chain): ?>
            <div class="c-footer__chain c-footer__top-item">
                <?php if ($chain_name): ?>
                    <?php p_title('div', $chain_name, '3'); ?>
                <?php endif; ?>

                <?php if (!empty($chain_hotels)): ?>
                    <div class="c-footer__chain-hotels">
                        <?php foreach ($chain_hotels as $hotel): ?>
                            <?php
                            $image = esc_html($hotel['image']);
                            $name = esc_html($hotel['content']['name']);
                            $description = wp_kses_post($hotel['content']['description']);
                            $url = esc_url($hotel['content']['url']);
                            ?>
                            <div class="c-footer__hotel">
                                <a class="c-footer__hotel-link" href="<?php echo $url; ?>" target="_blank"
                                    rel="noopener noreferrer">
                                    <?php if ($image): ?>
                                        <?php p_image($image); ?>
                                    <?php endif; ?>
                                    <div class="c-footer__hotel-content">
                                        <?php if ($name): ?>
                                            <div class="c-footer__hotel-name">
                                                <?php echo $name; ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($description): ?>
                                            <div class="c-footer__hotel-description">
                                                <?php echo $description; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (has_nav_menu('footer')): ?>
            <nav class="c-footer__nav c-footer__top-item">
                <?php p_title('div', wp_get_nav_menu_name('footer'), '3'); ?>
                <?php wp_nav_menu([
                    'theme_location' => 'footer',
                    'container' => false,
                    'menu_id' => '',
                    'fallback_cb' => false
                ]); ?>
            </nav>
        <?php endif; ?>

        <div class="c-footer__info c-footer__top-item">
            <?php p_title('div', 'Contact', '3'); ?>

            <div class="info__container">
                <div class="info__logo">
                    <?php if ($footer_logo_id): ?>
                        <a class="info__logo-link" href="<?php echo esc_url(home_url()); ?>">
                            <?php echo wp_get_attachment_image($footer_logo_id, 'medium_large'); ?>
                        </a>
                    <?php elseif (has_custom_logo()): ?>
                        <?php echo get_custom_logo(); ?>
                    <?php else: ?>
                        <a class="info__logo-link" href="<?php echo esc_url(home_url()); ?>">
                            <?php echo esc_html(get_bloginfo('name')); ?>
                        </a>
                    <?php endif; ?>
                </div>

                <div class="info__contact">
                    <div class="info__hotel-name">
                        <?php echo esc_html(get_bloginfo('name')); ?>
                    </div>
                    <?php if ($telephone): ?>
                        <div class="info__telephone">
                            <a href="tel:<?php echo esc_html($telephone); ?>">
                                <?php echo esc_html($telephone); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                    <?php if ($email): ?>
                        <div class="info__email">
                            <a href="mailto:<?php echo esc_html($email); ?>">
                                <?php echo esc_html($email); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                    <?php if ($address): ?>
                        <div class="info__address">
                            <?php echo esc_html($address); ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($locality): ?>
                        <div class="info__locality">
                            <?php echo esc_html($locality); ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($country): ?>
                        <div class="info__country">
                            <?php echo esc_html($country); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if (!empty($social_media)): ?>
                    <ul class="info__socials">
                        <?php foreach ($social_media as $social): ?>
                            <li class="info__social">
                                <a href="<?php echo esc_url($social['url']); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php p_icon(strtolower($social['platform'])); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <div class="layout c-footer__bottom">
        <?php echo do_shortcode('[nuna_wpml_language_selector class="c-footer__languages"]') ?>

        <?php $copyright = get_field('copyright', 'option'); ?>
        <?php if (!empty($copyright)): ?>
            <div class="c-footer__copyright">
                <?php echo wp_kses_post($copyright); ?>
            </div>
        <?php endif; ?>

        <?php if (has_nav_menu('policies')): ?>
            <nav class="c-footer__policies">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'policies',
                    'container' => false,
                    'menu_id' => '',
                    'echo' => true,
                    'fallback_cb' => false
                ));
                ?>
            </nav>
        <?php endif; ?>
    </div>
</footer>

<?php
c_action_bar($telephone, $social_media, 'Book');

wp_footer();

$hotel_id = get_field('hotel_id', 'option');
if (!empty($hotel_id)):
    ?>
    <script async type="module" defer src="https://static.mirai.com/core/index.js"></script>
<?php endif; ?>

</body>

</html>