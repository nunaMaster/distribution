<?php

// HOT CSS RELOAD ON LOCALHOST
function enqueue_dev_css_reload() {
	if ( $_SERVER['REMOTE_ADDR'] === '127.0.0.1' || $_SERVER['REMOTE_ADDR'] === '::1' ) {
		global $vite_css_file;
		if ( ! $vite_css_file ) {
			return;
		}

		echo "<script>
            (function () {
				console.log('dev');
                const manifestUrl = '" . get_template_directory_uri() . "/dist/.vite/manifest.json';
                let currentCss = '$vite_css_file';

                async function checkForNewCSS() {
                    try {
                        const response = await fetch(manifestUrl, { cache: 'no-store' });
                        const data = await response.json();
                        const newCss = data['css/styles.css']?.file;

                        if (newCss && newCss !== currentCss) {
                            currentCss = newCss;
                            const newLink = document.createElement('link');
                            newLink.rel = 'stylesheet';
                            newLink.href = '" . get_template_directory_uri() . "/dist/' + newCss + '?v=' + Date.now();

                            document.head.appendChild(newLink);

                            setTimeout(() => {
                                document.querySelectorAll('link[rel=\"stylesheet\"]')
                                    .forEach(link => {
                                        if (link.href.includes('/dist/assets/styles-') && link !== newLink) {
                                            link.remove();
                                        }
                                    });
                            }, 500);
                        }
                    } catch (err) {
                        console.error('Error checking for new CSS:', err);
                    }
                }

                setInterval(checkForNewCSS, 5000);
            })();
        </script>";
	}
}

add_action( 'wp_footer', 'enqueue_dev_css_reload' );