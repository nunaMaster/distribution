<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Dynamically populate the ACF select field with SVG icons
 * based on the Customizer setting.
 */
add_filter('acf/load_field/name=p_icon', function ($field) {
    $field['choices'] = [];

    // Get the selected icon style from Customizer (default: 'solid')
    $icon_style = get_theme_mod('icon_style', 'solid');

    // Define icon directory path
    $icon_dir = get_template_directory()."/dist/assets/icons/{$icon_style}/";

    // Fetch all SVG files
    $icons = glob($icon_dir.'*.svg', GLOB_BRACE);

    if ($icons) {
        foreach ($icons as $icon) {
            $icon_name = pathinfo($icon, PATHINFO_FILENAME); // Get file name without extension
            $field['choices'][$icon_name] = ucwords(str_replace('-', ' ', $icon_name)); // Format name
        }
    }

    return $field;
});

/**
 * Customize ACF Flexible Content layout title.
 *
 * This hook updates the label shown in the admin for each layout under the 'sections' flexible content field.
 * It replaces the default layout name with the value of a subfield called 'section_name', if available.
 *
 * @param  string  $title  Default layout title.
 * @param  array  $field  Flexible content field settings.
 * @param  array  $layout  Layout settings.
 * @param  int  $i  Layout index.
 *
 * @return string Custom layout title.
 */
add_filter('acf/fields/flexible_content/layout_title/name=sections', 'flexible_content_custom_label', 10, 4);

function flexible_content_custom_label($title, $field, $layout, $i)
{
    $section_name = get_sub_field('section_name');

    if ($section_name) {
        $title = '<strong>'.esc_html($section_name).'</strong>';
    }

    return $title;
}

add_action('admin_head', function () {
    if (!current_user_can('administrator')) {
        echo '<style>
			.acf-tab-button[data-key="field_680f4393e3da9"] {
				display: none !important;
			}
		</style>';
    }
});

add_action('acf/input/admin_head', function () {
    ?>
    <style>
        .acf-editor-wrap iframe {
            max-height: 200px;
            overflow-y: auto;
        }

        .acf-field textarea {
            max-height: 80px;
            overflow-y: auto;
        }
    </style>
    <?php
});

if (!function_exists('build_media_array')) {
    /**
     * Build a sanitized media array from a content list item.
     *
     * Returns null if no meaningful media content exists.
     *
     * @param  array  $item  Content list item.
     * @return array|null Media array or null if empty.
     */
    function build_media_array($item)
    {
        $media_type = $item['media_type'] ?? '';
        $gallery_layout = $item['gallery_layout'] ?? '';
        $gallery = !empty($item['gallery']) && is_array($item['gallery']) ? array_filter($item['gallery']) : [];
        $video = $item['video'] ?? '';
        $video_thumbnail = $item['video_thumbnail'] ?? '';

        if (empty($gallery) && empty($video)) {
            return null;
        }

        return [
            'media_type' => $media_type,
            'gallery_layout' => $gallery_layout,
            'gallery' => $gallery,
            'video' => $video,
            'video_thumbnail' => $video_thumbnail
        ];
    }
}