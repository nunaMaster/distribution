<?php
function nuna_get_available_fonts()
{
    $font_dir = get_template_directory().'/dist/assets/fonts/';
    $fonts = [];

    if (!is_dir($font_dir)) {
        return $fonts;
    }

    $files = scandir($font_dir);
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'woff2') {
            $parts = explode('-', $file);
            array_pop($parts); // remove weight/style part like "regular.woff2"
            $font_slug = implode('-', $parts);

            $font_name = ucwords(str_replace('-', ' ', $font_slug));
            $fonts[$font_name] = $font_name;
        }
    }

    ksort($fonts);

    return $fonts;
}
