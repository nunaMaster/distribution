<?php

function updates_checker($transient)
{

    $theme_slug = 'nunaBase';

    // Public version.json file
    $version_file_url = 'https://raw.githubusercontent.com/nunaMaster/distribution/main/nunaBase/version.json';

    // Exit if theme version info is not available
    if (empty($transient->checked[$theme_slug])) {
        return $transient;
    }

    // Fetch remote version file
    $response = wp_remote_get($version_file_url);

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        return $transient;
    }

    // Decode JSON response
    $remote = json_decode(wp_remote_retrieve_body($response));

    // Current version
    $current_version = wp_get_theme($theme_slug)->get('Version');

    // Compare remote version with current version
    if (version_compare($remote->version, $current_version, '>')) {
        $transient->response[$theme_slug] = [
            'theme' => $theme_slug,
            'new_version' => $remote->version,
            'url' => $remote->details_url,
            'package' => $remote->download_url,
            'sections' => [
                'changelog' => implode('<br>', $remote->changelog)
            ]
        ];
    }

    return $transient;
}

add_filter('site_transient_update_themes', 'updates_checker');