<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Require all template files from primitives and components folders.
 */
function require_template_files( $folder ) {
	$template_dir = get_template_directory() . "/templates/{$folder}/";

	// Get all PHP files in the folder
	$files = glob( $template_dir . '*.php' );

	if ( $files ) {
		foreach ( $files as $file ) {
			require_once $file;
		}
	}
}

// Load primitives and components
require_template_files( 'primitives' );
require_template_files( 'components' );