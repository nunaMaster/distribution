<?php

function enqueue_assets()
{
    $theme_uri = get_template_directory_uri();
    $theme_path = get_template_directory();

    wp_enqueue_style('flickity-css', $theme_uri.'/dev/src/css/flickity.min.css');
    wp_enqueue_script('flickity-js', $theme_uri.'/dev/src/js/flickity.pkgd.min.js', [], null, true);

    wp_enqueue_style('fancybox-css', $theme_uri.'/dev/src/css/fancybox.min.css');
    wp_enqueue_script('fancybox-js', $theme_uri.'/dev/src/js/fancybox.umd.min.js', [], null, true);

    $manifest_path = $theme_path.'/dist/.vite/manifest.json';

    if (!file_exists($manifest_path)) {
        error_log("Vite manifest not found at {$manifest_path}");
        return;
    }

    $manifest = json_decode(file_get_contents($manifest_path), true);

    // Load CSS
    $css_file = $manifest['src/scss/main.scss']['file'] ?? '';
    if ($css_file) {
        wp_enqueue_style('nuna-style', $theme_uri.'/dist/'.$css_file, [], null);
    }

    $selected_skin = get_theme_mod('selected_skin', 'nuna');
    if ($selected_skin !== 'nuna') {
        $skin_css_path = $theme_uri.'/dist/assets/skins/'.$selected_skin.'.css';
        wp_enqueue_style('custom-skin', $skin_css_path, [], null);
    }

    // Load JS
    $js_file = $manifest['src/js/main.js']['file'] ?? '';
    if ($js_file) {
        wp_enqueue_script('nuna-script', $theme_uri.'/dist/'.$js_file, [], null, true);
    }
}

add_action('wp_enqueue_scripts', 'enqueue_assets');