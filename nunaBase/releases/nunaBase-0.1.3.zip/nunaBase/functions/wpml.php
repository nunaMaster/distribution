<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ==============================================================================
 * WPML Integration for Nuna Theme
 * ==============================================================================
 * - Shortcode: Language switcher
 * - Theme mod string registration
 * - Helper: Get translated theme mod value
 * ==============================================================================
 */

/**
 * Shortcode: [nuna_wpml_language_selector class="your-class"]
 */
function nuna_wpml_language_selector_shortcode($atts)
{
    if (!defined('ICL_SITEPRESS_VERSION')) {
        return '';
    }

    $atts = shortcode_atts([
        'class' => '',
    ], $atts, 'nuna_wpml_language_selector');

    ob_start();
    ?>
    <div class="<?php echo esc_attr($atts['class']); ?>">
        <?php do_action('wpml_add_language_selector'); ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('nuna_wpml_language_selector', 'nuna_wpml_language_selector_shortcode');

/**
 * Register theme mod strings with WPML.
 */
function nuna_register_customizer_strings()
{
    if (!function_exists('icl_register_string')) {
        return;
    }

    $value = get_theme_mod('cta_label', 'Book');
    if (!empty($value)) {
        do_action('wpml_register_single_string', 'Theme Settings', 'Header CTA Label', $value);
    }
}
add_action('init', 'nuna_register_customizer_strings');

/**
 * Get translated theme mod value.
 *
 * @param string $mod_key Theme mod key.
 * @param string $context Context used in string registration (e.g. 'Theme Options').
 * @param string $label   Label used in string registration.
 * @return string         Translated string if WPML is active, otherwise original value.
 */
function nuna_get_translated_theme_mod($mod_key, $context, $label)
{
    $value = get_theme_mod($mod_key);

    if (function_exists('icl_t')) {
        return apply_filters('wpml_translate_single_string', $value, $context, $label);
    }

    return $value;
}

function nuna_localize_language_strings()
{
    if (!defined('ICL_SITEPRESS_VERSION')) {
        return;
    }

    $translations = [
        'book' => __('Book', 'nunabase'),
        'menu' => __('Menu', 'nunabase'),
    ];

    wp_localize_script('nuna-script', 'nunaLang', $translations);
}
add_action('wp_enqueue_scripts', 'nuna_localize_language_strings');
