<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

// Autoload all necessary files
$function_files = [
	'clean-wordpress',
	//'development-tools',
	'theme-support',
	'theme-images',
	'enqueue-assets',
	'customizer',
	'autoload-templates',
	'register-menus',
	'acf-fields',
	'shortcodes',
	'update-checker',
	'menu-walker',
];

foreach ($function_files as $file) {
	$file_path = get_template_directory() . "/functions/{$file}.php";

	if (file_exists($file_path)) {
		require_once $file_path;
	} else {
		error_log("Missing function file: {$file_path}"); // Logs missing files in debug.log
	}
}