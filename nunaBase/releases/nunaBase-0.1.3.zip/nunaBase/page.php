<?php
get_header();

while (have_posts()) {
	the_post();

	$show_hero = get_field('show_hero');

	if ($show_hero) {
		require get_template_directory() . '/templates/sections/s_hero.php';
	}

	$sections = get_field('sections');

	if (!empty($sections)) {
		foreach ($sections as $key => $section) {
			if (empty($section['acf_fc_layout'])) {
				continue;
			}

			$section_id = $key + 1;
			$layout_name = str_replace('section_', '', $section['acf_fc_layout']);
			$section_template = get_template_directory() . '/templates/sections/s_' . $layout_name . '.php';

			if (file_exists($section_template)) {
				require $section_template;
			}
		}
	}

}

get_footer();