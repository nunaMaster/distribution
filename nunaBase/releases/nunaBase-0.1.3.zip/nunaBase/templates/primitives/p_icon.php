<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render an icon.
 *
 * @param  string  $name  The name of the icon.
 */
function p_icon($name)
{
    $icon_style = get_theme_mod('icon_style', 'solid');
    $icon_path = get_template_directory()."/dist/assets/icons/{$icon_style}/{$name}.svg";

    if (file_exists($icon_path)) {
        $icon = file_get_contents($icon_path);
        echo '<span class="p-icon">'.$icon.'</span>';
    }
}