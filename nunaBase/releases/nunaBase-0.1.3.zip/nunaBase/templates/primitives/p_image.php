<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Component: p_image
 *
 * Render a single image with responsive sizes, alt text, and caption from ACF fields.
 *
 * @param int    $image            ACF image ID.
 */
function p_image($image, $lightbox = false, $gallery_id = null)
{
    if (empty($image)) {
        return;
    }

    // Responsive sizes for images
    $sizes = "(max-width: 480px) 100vw, (max-width: 768px) 100vw, (max-width: 1024px) 90vw, (max-width: 1440px) 80vw, 1440px";

    // Set up image attributes
    $attributes = [
        'alt' => get_post_meta($image, '_wp_attachment_image_alt', true) ?: '',
        'sizes' => $sizes,
    ];

    // Get the image caption
    $caption = wp_get_attachment_caption($image); // Get the caption

    // Lightbox href (if enabled)
    $lightbox_url = $lightbox ? esc_url(wp_get_attachment_image_url($image, 'full')) : '';
    $data_fancybox = $gallery_id ? ' data-fancybox="gallery-' . esc_attr($gallery_id) . '"' : '';
    ?>
    <figure class="p-image">
        <div class="p-image__image">
            <?php if ($lightbox_url): ?>
                <a href="<?php echo $lightbox_url; ?>" <?php echo $data_fancybox; ?>>
                    <?php echo wp_get_attachment_image($image, 'full', false, $attributes); ?>
                </a>
            <?php else: ?>
                <?php echo wp_get_attachment_image($image, 'full', false, $attributes); ?>
            <?php endif; ?>
        </div>

        <?php if ($caption): ?>
            <figcaption class="p-image__caption">
                <?php echo wp_kses_post($caption); ?>
            </figcaption>
        <?php endif; ?>
    </figure>
    <?php
}