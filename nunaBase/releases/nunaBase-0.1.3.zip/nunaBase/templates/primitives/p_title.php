<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * @param  string  $tag  HTML tag to use (h1, h2, h3, div).
 * @param  string  $title  The text content of the title.
 * @param  string  $variation  The style variation (1, 2, 3).
 */
function p_title($tag = 'h2', $title = '', $variation = '2')
{
	if (!$title) {
		return;
	}

	$class = [
		'1' => "p-title--lg",
		'2' => "p-title--md",
		'3' => "p-title--sm"
	];

	$title_html = '<' . esc_html($tag) . ' class="p-title ' . esc_attr($class[$variation]) . '">';
	$title_html .= esc_html($title);
	$title_html .= '</' . esc_html($tag) . '>';

	echo $title_html;
}