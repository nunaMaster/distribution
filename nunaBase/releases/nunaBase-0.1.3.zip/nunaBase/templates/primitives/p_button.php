<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Generate a button with optional icon and style variations.
 *
 * @param string $icon       The icon for the button (optional).
 * @param array  $link       ACF link array (url, title, target).
 * @param string $variation  The style variation (1, 2, 3).
 */
function p_button($icon, $link, $variation = '1')
{
	if (empty($link) || !isset($link['url'], $link['title'])) {
		return;
	}

	$url = esc_url($link['url']);
	$label = esc_html($link['title']);
	$target = !empty($link['target']) ? esc_attr($link['target']) : '_self';

	$classes = [
		'1' => '',
		'2' => 'p-button--secondary',
		'3' => 'p-button--link',
	];

	echo '<a href="' . $url . '" class="p-button ' . esc_attr($classes[$variation]) . '" target="' . $target . '">';

	if ($icon) {
		p_icon($icon);
	}

	if ($label) {
		echo '<span class="p-button__label">' . $label . '</span>';
	}

	echo '</a>';
}