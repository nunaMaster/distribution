<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Hero Section
 *
 * @param  array  $content  Flexible content field containing various content blocks.
 * @param  int  $image  Image.
 * @param  array  $bg_media  Media.
 */

// ACF Fields
$show_booking_finder = get_field('show_booking_finder');
$content = get_field('content');
$image = get_field('hero_image');
$bg_media = get_field('hero_bg_media');

if (empty($content) && empty($image) && empty($bg_media)) {
	return;
}

$hotel_id = get_field('hotel_id', 'option');

$class = is_front_page() || is_home() ? 's-hero--homepage' : '';

$section_id = 1;
?>

<section class="s-hero <?php echo esc_attr($class); ?>">
	<?php if (!empty($bg_media)): ?>
		<?php c_media($bg_media, [
			'draggable' => false,
			'wrapAround' => true,
			'autoPlay' => true,
			'pauseAutoPlayOnHover' => true,
			'prevNextButtons' => false,
			'pageDots' => false
		], $section_id); ?>
	<?php endif; ?>

	<div class="layout">
		<?php if (!empty($content)): ?>
			<?php c_content($content); ?>
		<?php endif; ?>

		<?php if (!empty($image)): ?>
			<div class="s-hero__image">
				<?php p_image($image); ?>
			</div>
		<?php endif; ?>

		<?php if ($show_booking_finder && !empty($hotel_id)): ?>
			<div data-mirai-component="finder" data-mobile="false"></div>
		<?php endif; ?>
	</div>
</section>