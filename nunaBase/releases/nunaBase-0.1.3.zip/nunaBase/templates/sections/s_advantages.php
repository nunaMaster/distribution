<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Advantages Section
 *
 * @param  array  $content  Flexible content field containing various content blocks.
 * @param  array  $advantages  List of advantages.
 * @param  string  $classes  Classes for section.
 * @param  int  $bg_image  Background image field from ACF.
 */

$content = $section['content'];
$advantages = $section['advantages'];
$classes = $section['classes'] ?? '';
$bg_image = $section['advantages_bg_image'] ?? null;

if (empty($content) && empty($advantages)) {
	return;
}

$style = '';
if ($bg_image) {
	$bg_url = wp_get_attachment_image_url($bg_image, 'full');
	if ($bg_url) {
		$style = ' style="background-image: url(' . esc_url($bg_url) . ');"';
	}
}
?>

<section class="s-advantages <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php if ($content): ?>
			<?php c_content($content); ?>
		<?php endif; ?>
		<?php if ($advantages): ?>
			<?php c_advantages($advantages); ?>
		<?php endif; ?>
	</div>
</section>