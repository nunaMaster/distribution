<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Section: Content List
 *
 * Outputs a list of content blocks, each optionally with media and rich content.
 *
 * @param array $section Flexible content block containing 'content_list'.
 */

$content = $section['content'] ?? null;
$content_list = $section['content_list'] ?? [];
$bg_image = $section['content_list_bg_image'] ?? null;
$classes = $section['classes'] ?? '';
$max_images = $section['max_images'] ?? null;

if (empty($content) && empty($content_list)) {
	return;
}

// Background style
$style = '';
if ($bg_image) {
	$bg_url = wp_get_attachment_image_url($bg_image, 'full');
	if ($bg_url) {
		$style = ' style="--bg-image: url(' . esc_url($bg_url) . ');"';
	}
}
?>

<section class="s-content-list <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<?php if ($content): ?>
		<div class="layout">
			<?php c_content($content); ?>
		</div>
	<?php endif; ?>

	<?php if ($content_list): ?>
		<div class="s-content-list__items">
			<?php foreach ($content_list as $item):
				$item_content = $item['content'] ?? null;
				$item_media = build_media_array($item);
				$item_bg_image = $item['bg_image'] ?? null;

				if (empty($item_content) && empty($item_media)) {
					continue;
				}

				$item_style = '';
				if ($item_bg_image) {
					$item_bg_url = wp_get_attachment_image_url($item_bg_image, 'full');
					if ($item_bg_url) {
						$item_style = ' style="background-image: url(' . esc_url($item_bg_url) . ');"';
					}
				}
				?>

				<div class="s-content-list__item" <?php echo $item_style; ?>>
					<?php if ($item_content): ?>
						<?php c_content($item_content); ?>
					<?php endif; ?>

					<?php if ($item_media): ?>
						<?php c_media($item_media, [
							'draggable' => false,
							'wrapAround' => true,
							'pageDots' => false
						], $section_id, $max_images); ?>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>