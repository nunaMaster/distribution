<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Advantages Section
 *
 * @param array $content Flexible content field containing various content blocks.
 * @param array $rooms   List of room post IDs.
 */

$content = $section['content'] ?? null;
$rooms = $section['rooms'] ?? [];
$bg_image = $section['rooms_bg_image'] ?? null;
$classes = $section['classes'] ?? '';

if (empty($content) && empty($rooms)) {
	return;
}

// Background style
$style = '';
if ($bg_image) {
	$bg_url = wp_get_attachment_image_url($bg_image, 'full');
	if ($bg_url) {
		$style = ' style="background-image: url(' . esc_url($bg_url) . ');"';
	}
}
?>

<section class="s-rooms <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php if (!empty($content)) {
			c_content($content);
		} ?>

		<?php if (!empty($rooms)):

			$rooms_query = new WP_Query([
				'post_type' => 'room',
				'posts_per_page' => -1,
				'post__in' => $rooms,
				'orderby' => 'post__in',
			]);

			if ($rooms_query->have_posts()): ?>
				<div class="s-rooms__list">
					<?php while ($rooms_query->have_posts()):
						$rooms_query->the_post();
						$gallery = get_field('gallery'); ?>
						<?php c_room($gallery, get_the_ID()); ?>
					<?php endwhile; ?>
				</div>
				<?php wp_reset_postdata();
			endif;
		endif; ?>
	</div>
</section>