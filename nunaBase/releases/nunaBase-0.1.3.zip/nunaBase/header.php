<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- SEO & Open Graph -->
    <meta name="description" content="<?php echo esc_attr(get_bloginfo('description', 'display')); ?>">
    <meta property="og:title" content="<?php bloginfo('name'); ?>">
    <meta property="og:description" content="<?php echo esc_attr(get_bloginfo('description', 'display')); ?>">
    <meta property="og:url" content="<?php echo esc_url(home_url()); ?>">
    <meta property="og:type" content="website">
    <meta property="og:image" content="<?php echo esc_url(get_template_directory_uri() . '/screenshot.png'); ?>">

    <!-- Favicon & Theme Color -->
    <link rel="icon" href="<?php echo esc_url(get_template_directory_uri() . '/favicon.ico'); ?>" type="image/x-icon">
    <meta name="theme-color" content="#ffffff">

    <?php $hotel_id = get_field('hotel_id', 'option'); ?>
    <?php if (!empty($hotel_id)): ?>
        <link rel="preload" as="style" href="https://static.mirai.com/core/index.css"
            onload="this.onload=null;this.rel='stylesheet'" />
    <?php endif; ?>

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <?php if (!empty($hotel_id)): ?>
        <div data-mirai-id="<?php echo esc_attr($hotel_id); ?>"></div>
    <?php endif; ?>

    <?php
    // Cache menu and theme settings
    $header_menu = wp_nav_menu([
        'theme_location' => 'header',
        'container' => false,
        'menu_id' => '',
        'echo' => false,
        'fallback_cb' => false
    ]);

    $header_layout = get_theme_mod('header_layout', 'default');

    // Header layout classes map
    $header_classes = [
        'logo_left_menu_center' => 'c-header--menu-center',
        'logo_left_hamburger_left' => 'c-header--hamburger c-header--hamburger-left',
        'logo_left_hamburger_right' => 'c-header--hamburger c-header--hamburger-right',
        'logo_center_menu_split' => 'c-header--logo-center c-header--menu-split',
        'logo_center_hamburger_left' => 'c-header--logo-center c-header--hamburger',
        'logo_center_hamburger_right' => 'c-header--logo-center c-header--hamburger c-header--hamburger-right',
    ];

    $header_class = $header_classes[$header_layout] ?? '';
    $site_name = get_bloginfo('name');
    $home_url = esc_url(home_url());
    ?>

    <header class="c-header <?php echo esc_attr($header_class); ?>">
        <div class="c-header__container">
            <div class="c-header__logo">
                <?php if (has_custom_logo()) {
                    the_custom_logo();
                } else { ?>
                    <a class="c-header__logo-link" href="<?php echo $home_url; ?>">
                        <h1><?php echo esc_html($site_name); ?></h1>
                    </a>
                <?php } ?>
            </div>

            <?php if ($header_menu): ?>
                <nav class="c-header__nav">
                    <?php echo $header_menu ?>
                </nav>
            <?php endif; ?>

            <button class="c-header__hamburger" data-show-modal="header-overlay-panel" data-panel-toggle="menu">
                <span class="c-header__hamburger-line c-header__hamburger-line--left"></span>
                <span class="c-header__hamburger-line"></span>
                <span class="c-header__hamburger-line c-header__hamburger-line--right"></span>
            </button>

            <?php if (get_theme_mod('show_cta')): ?>
                <button class="c-header__cta p-button" data-show-modal="header-overlay-panel" data-panel-toggle="book">
                    <?php echo esc_html(nuna_get_translated_theme_mod('cta_label', 'Theme Settings', 'Header CTA Label')); ?>
                </button>
            <?php endif; ?>
        </div>

        <?php
        /** HEADER PANEL COMPONENTS **/

        // Panel Header
        ob_start(); ?>
        <div class="panel__logo c-header__logo">
            <?php if (has_custom_logo()) {
                the_custom_logo();
            } else { ?>
                <a class="panel__logo-link" href="<?php echo $home_url; ?>">
                    <?php echo esc_html($site_name); ?>
                </a>
            <?php } ?>
        </div>
        <button class="panel__cta-booking p-button" data-panel-toggle="toggle">
            <?php echo esc_html(nuna_get_translated_theme_mod('cta_label', 'Theme Settings', 'Header CTA Label')); ?>
        </button>
        <?php
        $panel_header = ob_get_clean();

        // Panel Body
        ob_start();
        ?>
        <div class="c-modal__body-wrapper" data-state="menu">
            <?php
            $panel_menu = wp_nav_menu([
                'theme_location' => 'header',
                'container' => false,
                'menu_id' => '',
                'echo' => false,
                'fallback_cb' => false,
                'walker' => new Walker_Nav_Menu_With_Description(),
            ]);

            if ($panel_menu): ?>
                <nav class="panel__menu">
                    <?php echo $panel_menu ?>
                </nav>
            <?php endif;

            if (!empty($hotel_id)): ?>
                <div class="panel__booking">
                    <div data-mirai-component="finder"></div>
                    <?php
                    $advantages = get_field('hotel_advantages', 'option');
                    if (!empty($advantages)) {
                        c_advantages($advantages['advantages']);
                    }
                    ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        $panel_body = ob_get_clean();

        // Panel Footer
        ob_start();

        echo do_shortcode('[nuna_wpml_language_selector class="panel__languages"]');

        $telephone = get_field('telephone', 'option');
        $email = get_field('email', 'option');
        ?>

        <div class="panel__contact">
            <?php if ($telephone): ?>
                <a class="panel__contact-link" href="tel:<?php echo esc_attr($telephone); ?>">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 256 256">
                            <path fill="currentColor"
                                d="M148.14 47a4 4 0 0 1 4.86-2.87A82.24 82.24 0 0 1 211.86 103a4 4 0 0 1-2.83 4.89a3.7 3.7 0 0 1-1 .14a4 4 0 0 1-3.86-3A74.35 74.35 0 0 0 151 51.86a4 4 0 0 1-2.86-4.86M143 83.86C158 87.89 168.11 98 172.14 113a4 4 0 0 0 3.86 3a3.7 3.7 0 0 0 1-.14a4 4 0 0 0 2.83-4.89c-4.8-18-16.85-30-34.83-34.84a4 4 0 0 0-2 7.73m76.94 98.72A52.25 52.25 0 0 1 168 228C90.8 228 28 165.2 28 88a52.25 52.25 0 0 1 45.42-51.91a12 12 0 0 1 12.48 7.19L107 90.42a12 12 0 0 1-1 11.36c-.09.13-.18.26-.28.38l-21.2 25.21a3.9 3.9 0 0 0-.18 3.69c7.84 16.05 24.65 32.73 40.89 40.57a3.93 3.93 0 0 0 3.7-.21l24.87-21.12l.38-.29a12 12 0 0 1 11.38-1l47.22 21.16a12 12 0 0 1 7.13 12.41Zm-10.35-5.12l-47.24-21.16a3.93 3.93 0 0 0-3.57.27L134 177.69l-.37.28a12 12 0 0 1-11.79.87c-18-8.69-35.91-26.48-44.6-44.27a12 12 0 0 1 .76-11.75c.09-.14.19-.26.29-.39l21.19-25.2a4 4 0 0 0 .23-3.6L78.57 46.49A4 4 0 0 0 74.9 44a4 4 0 0 0-.48 0A44.23 44.23 0 0 0 36 88c0 72.78 59.22 132 132 132a44.23 44.23 0 0 0 44-38.42a4 4 0 0 0-2.44-4.12Z">
                            </path>
                        </svg>
                    </span>
                    <span class="label">
                        <?php echo esc_html($telephone); ?>
                    </span>
                </a>
            <?php endif; ?>

            <?php if ($email): ?>
                <a class="panel__contact-link" href="mailto:<?php echo esc_attr($email); ?>">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                            <path fill="currentColor"
                                d="M5 5h13a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3m0 1c-.5 0-.94.17-1.28.47l7.78 5.03l7.78-5.03C18.94 6.17 18.5 6 18 6zm6.5 6.71L3.13 7.28C3.05 7.5 3 7.75 3 8v9a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2V8c0-.25-.05-.5-.13-.72z">
                            </path>
                        </svg>
                    </span>
                    <span class="label">
                        <?php echo esc_html($email); ?>
                    </span>
                </a>
            <?php endif; ?>
        </div>

        <?php $panel_footer = ob_get_clean();

        // Render Modal
        c_modal('header-overlay-panel', $panel_header, $panel_body, $panel_footer);
        ?>
    </header>

    <main>