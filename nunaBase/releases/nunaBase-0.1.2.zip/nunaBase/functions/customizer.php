<?php

if (class_exists('WP_Customize_Control')) {
	/**
	 * Custom Reset Control.
	 */
	class Nuna_Reset_Control extends WP_Customize_Control
	{
		public $type = 'reset';

		public function render_content()
		{
			// Build current URL with the reset parameter.
			$reset_url = add_query_arg('reset_theme_options', '1');
			?>
			<label>
				<span class="customize-control-title"><?php esc_html_e('Reset Options', 'nunabase'); ?></span>
				<a href="<?php echo esc_url($reset_url); ?>" class="button button-secondary">
					<?php esc_html_e('Reset To Defaults', 'nunabase'); ?>
				</a>
			</label>
			<?php
		}
	}
}

function nuna_reset_theme_options()
{
	// Check for the reset query parameter.
	if (isset($_GET['reset_theme_options']) && '1' === $_GET['reset_theme_options']) {
		// List all the keys you wish to reset.
		$keys = array('icon_style');
		foreach ($keys as $key) {
			remove_theme_mod($key);
		}
		// Redirect back to the current URL without the reset parameter.
		$redirect = remove_query_arg('reset_theme_options');
		wp_safe_redirect($redirect);
		exit;
	}
}

add_action('admin_init', 'nuna_reset_theme_options');

function get_skin_choices()
{
	$skin_dir = get_stylesheet_directory() . '/public/assets/skins/';
	$files = glob($skin_dir . '*.css');
	$choices = ['nuna' => 'Nuna'];

	foreach ($files as $file_path) {
		$filename = basename($file_path, '.css');
		$label = ucfirst($filename);
		$choices[$filename] = $label;
	}

	return $choices;
}

/**
 * Theme Customizer Settings
 *
 * Create one section "Theme Settings" that includes two parts:
 *   1. Typography: heading font, body font.
 *   2. Colors: site background, heading, body, button, link.
 */

function nuna_customize_register($wp_customize)
{
	// Add Footer Logo setting
	$wp_customize->add_setting('footer_logo', [
		'default' => '',
		'sanitize_callback' => 'absint', // Sanitize attachment ID
	]);

	// Add Footer Logo control
	$wp_customize->add_control(new WP_Customize_Media_Control(
		$wp_customize,
		'footer_logo',
		[
			'label' => __('Footer Logo', 'nunabase'),
			'section' => 'title_tagline', // Site Identity
			'mime_type' => 'image',
			'priority' => 8, // just below the regular logo
		]
	));

	// Add one section for all settings.
	$wp_customize->add_section('theme_settings', array(
		'title' => __('Theme Settings', 'nunabase'),
		'priority' => 30,
	));

	$wp_customize->add_setting('selected_skin', [
		'default' => 'nuna',
		'sanitize_callback' => 'sanitize_text_field',
	]);

	$wp_customize->add_control('selected_skin', [
		'label' => __('Skin', 'nunabase'),
		'section' => 'theme_settings',
		'type' => 'select',
		'choices' => get_skin_choices(),
	]);

	$wp_customize->add_setting('header_layout', [
		'default' => 'default',
		'sanitize_callback' => 'sanitize_text_field',
	]);

	$wp_customize->add_control('header_layout', [
		'label' => __('Header Layout', 'nunabase'),
		'section' => 'theme_settings',
		'type' => 'select',
		'choices' => [
			'default' => __('Logo Left - Menu Right (Default)', 'nunabase'),
			'logo_left_hamburger_right' => __('Logo Left - Hamburger Right', 'nunabase'),
			'logo_center_menu_split' => __('Logo Center - Split Menu', 'nunabase'),
			'logo_center_hamburger_left' => __('Logo Center - Hamburger Left', 'nunabase'),
			'logo_center_hamburger_right' => __('Logo Center - Hamburger Right', 'nunabase'),
		],
	]);

	// Icon Style
	$wp_customize->add_setting('icon_style', array(
		'default' => 'solid',
		'sanitize_callback' => 'sanitize_text_field',
	));
	$wp_customize->add_control('icon_style', array(
		'label' => __('Icon Style', 'nunabase'),
		'type' => 'radio',
		'section' => 'theme_settings',
		'choices' => array(
			'solid' => __('Solid', 'nunabase'),
			'outline' => __('Outline', 'nunabase'),
		),
	));

	/*-------------------------------------------
														  | Reset Button Control
														  -------------------------------------------*/
	$wp_customize->add_setting('theme_reset', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_text_field',
	));
	$wp_customize->add_control(new Nuna_Reset_Control($wp_customize, 'theme_reset', array(
		'section' => 'theme_settings',
		'priority' => 100, // Adjust for desired placement in the section.
	)));
}

add_action('customize_register', 'nuna_customize_register');

/**
 * Output custom styles based on Customizer settings.
 */
function theme_customizer_styles()
{
	$icon_style = get_theme_mod('icon_style', 'solid');

	?>
	<style>
		:root {
			--icon-style:
				<?php echo esc_attr($icon_style); ?>
			;
		}
	</style>
	<?php
}

add_action('wp_head', 'theme_customizer_styles');

