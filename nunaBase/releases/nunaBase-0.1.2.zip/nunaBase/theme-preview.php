<?php
/**
 * Template Name: Theme Preview
 * Description: Preview all theme primitives, components, and sections.
 */

get_header();
?>

<div class="theme-preview">
	<div class="layout">
		<h1>🎨 Theme Preview</h1>

		<section class="theme-preview__fonts">
			<h2>🔤 Fonts</h2>
			<h3 style="font-family: var(--heading-font);">
				Heading font:
			</h3>
			<p style="font-family: var(--body-font);">
				Body font: The quick brown fox jumps over the lazy dog
			</p>
		</section>

		<hr>

		<section class="theme-preview__colors">
			<h2>🌈 Colors</h2>
			<ul class="theme-preview__colors-list">
				<?php
				$colors = [
					'--site-background-color' => 'Site Background',
					'--heading-color' => 'Heading',
					'--body-color' => 'Body Text',
					'--color-brand' => 'Primary',
					'--secondary-color' => 'Secondary',
					'--accent-color' => 'Accent',
				];

				foreach ($colors as $var => $label): ?>
					<li style="display: inline-block; width: 120px; margin: 0.5rem;">
						<div
							style="width: 100%; height: 60px; background-color: var(<?php echo $var; ?>); border: 1px solid #ccc;">
						</div>
						<small><?php echo $label; ?><br><code><?php echo $var; ?></code></small>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>

		<hr>

		<section>
			<h2>🧩 Primitives</h2>
		</section>

		<hr>

		<section>
			<h2>📦 Components</h2>
		</section>

		<hr>

		<section>
			<h2>📑 Sections</h2>
		</section>
	</div>
</div>

<script>
	document.addEventListener('DOMContentLoaded', () => {
		// Show resolved color values
		const colorItems = document.querySelectorAll('.theme-preview__colors-list li');

		colorItems.forEach(item => {
			const codeEl = item.querySelector('code');
			const varName = codeEl.textContent;

			const computedValue = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
			const smallEl = item.querySelector('small');

			if (computedValue) {
				const resolved = document.createElement('div');
				resolved.innerHTML = `<br><span style="font-size: 0.75rem; color: #666;">${computedValue}</span>`;
				smallEl.appendChild(resolved);
			}
		});

		// Show resolved font values
		const fontElements = document.querySelectorAll('.theme-preview__fonts-heading, .theme-preview__fonts-body');

		fontElements.forEach(el => {
			const computedFont = getComputedStyle(el).fontFamily;
			const info = document.createElement('span');
			info.innerHTML = `<small style="font-size: 0.75rem; display: block; color: #666;">Resolved: ${computedFont}</small>`;
			el.appendChild(info);
		});
	});
</script>

<?php
get_footer();
