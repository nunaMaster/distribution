<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Rooms Component.
 *
 * @param array $gallery Array of image IDs for the room gallery.
 */
function c_room($gallery, $room_id)
{
	?>
	<article <?php post_class('c-room c-card'); ?>>

		<?php if (!empty($gallery)): ?>
			<div class="c-room__gallery c-card__gallery"
				data-flickity='{"draggable": false, "wrapAround": true, "pageDots": false}'>
				<?php foreach ($gallery as $gallery_image): ?>
					<div class="carousel-cell">
						<a href="<?php echo wp_get_attachment_image_url($gallery_image['ID'], 'full') ?>"
							data-fancybox="room-gallery-<?php echo $room_id ?>">
							<?php p_image($gallery_image['ID']); ?>
						</a>
					</div>
				<?php endforeach; ?>
			</div>

		<?php elseif (has_post_thumbnail()): ?>
			<div class="c-room__image">
				<?php the_post_thumbnail('medium_large'); ?>
			</div>
		<?php endif; ?>

		<div class="c-room__content">
			<h3><?php the_title(); ?></h3>

			<?php if (has_excerpt()): ?>
				<p><?php echo esc_html(get_the_excerpt()); ?></p>
			<?php endif; ?>

			<a href="<?php the_permalink(); ?>" class="p-button">
				<?php esc_html_e('View Room', 'nunabase'); ?>
			</a>
		</div>
	</article>
	<?php
}
