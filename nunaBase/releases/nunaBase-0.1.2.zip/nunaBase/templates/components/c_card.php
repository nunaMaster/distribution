<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Image & Content Component.
 *
 * @param  int|string  $image_id  Image attachment ID (from Media Library).
 * @param  array  $content  Content array (title, desc, button).
 * @param  string  $size  Image size (default: 'medium_large').
 * @param  string  $class  Additional CSS classes.
 */

function c_card($gallery, $image, $content, $card_id)
{
	if (empty($gallery) && empty($image) && empty($content)) {
		return;
	}
	?>
	<div class="c-card">
		<?php if (!empty($gallery)): ?>
			<div class="c-card__gallery" data-flickity='{ "draggable": false, "wrapAround": true, "pageDots": false }'>
				<?php foreach ($gallery as $gallery_image): ?>
					<div class="carousel-cell">
						<a href="<?php echo wp_get_attachment_image_url($gallery_image, 'full') ?>"
							data-fancybox="card-gallery-<?php echo $card_id ?>">
							<?php p_image($gallery_image); ?>
						</a>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if (!empty($image)): ?>
			<div class="c-card__image">
				<?php p_image($image); ?>
			</div>
		<?php endif; ?>

		<?php if (!empty($content)): ?>
			<?php c_content($content); ?>
		<?php endif; ?>
	</div>
	<?php
}