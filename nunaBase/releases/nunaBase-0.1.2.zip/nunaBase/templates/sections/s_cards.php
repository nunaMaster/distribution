<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Gallery Content Section Template
 *
 * @param  array  $content  Flexible content field containing various content blocks.
 * @param  array  $cards  Array of cards from the ACF repeater field.
 * @param  array  $bg_image  Background image field from ACF.
 */

$content = $section['content'];
$cards = $section['cards_list'] ?? [];
$bg_image = $section['cards_bg_image'];
$classes = $section['classes'] ?? '';

if (empty($content) && empty($cards)) {
	return;
}

$style = '';
if ($bg_image) {
	$bg_url = wp_get_attachment_image_url($bg_image, 'full');
	if ($bg_url) {
		$style = ' style="background-image: url(' . esc_url($bg_url) . ');"';
	}
}
?>

<section class="s-cards <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php if (!empty($content)): ?>
			<?php c_content($content) ?>
		<?php endif; ?>

		<?php if (!empty($cards)): ?>
			<ul class="cards">
				<?php foreach ($cards as $key => $card): ?>
					<li class="card">
						<?php c_card($card['gallery'], $card['image'], $card['content'], $key) ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>