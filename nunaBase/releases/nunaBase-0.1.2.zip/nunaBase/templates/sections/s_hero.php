<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Hero Section
 *
 * @param  array  $content  Flexible content field containing various content blocks.
 * @param  int  $image  Image.
 * @param  array  $bg_media  Media.
 */

// ACF Fields
$content = get_field('content');
$image = get_field('hero_image');
$bg_media = get_field('hero_bg_media');

if (empty($content) && empty($image) && empty($bg_media)) {
	return;
}

$class = is_front_page() || is_home() ? 's-hero--homepage' : '';

$section_id = 1;
?>

<section class="s-hero <?php echo esc_attr($class); ?>">
	<?php if (!empty($bg_media)): ?>
		<?php c_media($bg_media, [
			'draggable' => false,
			'wrapAround' => true,
			'autoPlay' => true,
			'pauseAutoPlayOnHover' => true,
			'prevNextButtons' => false,
			'pageDots' => false
		], $section_id); ?>
	<?php endif; ?>

	<?php if (!empty($content) || !empty($image)): ?>
		<div class="layout">
			<?php if (!empty($content)): ?>
				<?php c_content($content); ?>
			<?php endif; ?>

			<?php if (!empty($image)): ?>
				<div class="s-hero__image">
					<?php p_image($image); ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</section>