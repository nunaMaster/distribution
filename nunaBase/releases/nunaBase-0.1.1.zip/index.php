<?php get_header(); ?>

<main class="l-single bg-blue" role="main">
	Hello
</main>
<pre><?php print_r( get_intermediate_image_sizes() ); ?></pre>

<?php phpinfo(); ?>

<?php get_footer(); ?>


