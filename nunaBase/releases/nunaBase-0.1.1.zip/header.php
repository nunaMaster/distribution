<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<!-- SEO & Open Graph -->
	<meta name="description" content="<?php echo esc_attr(get_bloginfo('description', 'display')); ?>">
	<meta property="og:title" content="<?php bloginfo('name'); ?>">
	<meta property="og:description" content="<?php echo esc_attr(get_bloginfo('description', 'display')); ?>">
	<meta property="og:url" content="<?php echo esc_url(home_url()); ?>">
	<meta property="og:type" content="website">
	<meta property="og:image" content="<?php echo esc_url(get_template_directory_uri() . '/screenshot.png'); ?>">

	<!-- Favicon & Theme Color -->
	<link rel="icon" href="<?php echo esc_url(get_template_directory_uri() . '/favicon.ico'); ?>" type="image/x-icon">
	<meta name="theme-color" content="#ffffff">

	<?php $hotel_id = get_field('hotel_id', 'option'); ?>
	<?php if (!empty($hotel_id)): ?>
		<link rel="preload" as="style" href="https://static.mirai.com/core/index.css"
			onload="this.onload=null;this.rel='stylesheet'" />
	<?php endif; ?>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<?php if (!empty($hotel_id)): ?>
		<div data-mirai-id="<?php echo $hotel_id; ?>"></div>
	<?php endif; ?>

	<?php
	$header_menu = wp_nav_menu(array(
		'theme_location' => 'header',
		'container' => false,
		'fallback_cb' => false,
		'menu_id' => '',
		'echo' => false,
		'fallback_cb' => false
	));

	$header_layout = get_theme_mod('header_layout', 'default');

	$classes = [
		'logo_left_hamburger_right' => 'c-header--hamburger',
		'logo_center_menu_split' => 'c-header--logo-center c-header--menu-split',
		'logo_center_hamburger_left' => 'c-header--logo-center c-header--hamburger',
		'logo_center_hamburger_right' => 'c-header--logo-center c-header--hamburger c-header--hamburger-right',
	];

	$class = $classes[$header_layout] ?? '';
	?>

	<header class="c-header <?php echo esc_attr($class); ?>">
		<div class="c-header__container">
			<div class="c-header__logo">
				<?php if (has_custom_logo()): ?>
					<?php the_custom_logo(); ?>
				<?php else: ?>
					<a class="c-header__logo-link" href="<?php echo esc_url(home_url()) ?>">
						<h1><?php echo esc_html(get_bloginfo('name')); ?></h1>
					</a>
				<?php endif; ?>
			</div>

			<?php if (!empty($header_menu)): ?>
				<nav class="c-header__nav">
					<?php echo $header_menu ?>
				</nav>

				<div class="c-header__hamburger" aria-label="Toggle menu" role="button" tabindex="0">
					<span class="c-header__hamburger-line c-header__hamburger-line--left"></span>
					<span class="c-header__hamburger-line"></span>
					<span class="c-header__hamburger-line c-header__hamburger-line--right"></span>
				</div>
			<?php endif; ?>
		</div>

		<?php if (!empty($header_menu)): ?>
			<div class="c-header__nav-mobile-container">
				<nav class="c-header__nav-mobile">
					<?php echo $header_menu ?>
				</nav>
			</div>
		<?php endif; ?>
	</header>

	<main>