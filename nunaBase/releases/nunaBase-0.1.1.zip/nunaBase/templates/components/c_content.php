<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Render a content component.
 *
 * @param  array  $content  An array of ACF flexible content blocks.
 */
function c_content($content)
{
	if (empty($content)) {
		return;
	}

	echo '<div class="c-content">';

	foreach ($content as $block) {
		$layout = $block['acf_fc_layout'] ?? '';

		if (!$layout) {
			continue;
		}

		switch ($layout) {
			case 'eyebrow':
				if (!empty($block['eyebrow'])) {
					echo '<div class="c-content__eyebrow">' . wp_kses_post($block['eyebrow']) . '</div>';
				}
				break;

			case 'title':
				p_title($block['tag'], $block['title'], $block['variation']);
				break;

			case 'description':
				if (!empty($block['description'])) {
					echo '<div class="c-content__description">' . wp_kses_post($block['description']) . '</div>';
				}
				break;

			case 'buttons':
				if (!empty($block['buttons'])) {
					echo '<ul class="c-content__buttons">';
					foreach ($block['buttons'] as $button) {
						echo '<li class="c-content__button">';
						p_button($button['p_icon'], $button['link'], $button['variation']);
						echo '</li>';
					}
					echo '</ul>';
				}
				break;
		}
	}

	echo '</div>';
}