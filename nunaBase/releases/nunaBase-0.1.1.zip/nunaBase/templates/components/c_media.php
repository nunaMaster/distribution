<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Component: c_media
 *
 * Render a media block from ACF fields (gallery or video).
 *
 * @param array $media            ACF media array with media_type, images, or video.
 * @param array $carousel_options Flickity options as associative array.
 */
function c_media($media, $carousel_options = [], $gallery_id = null, $max_images = null)
{
	if (empty($media)) {
		return;
	}

	$type = $media['media_type'] ?? 'Gallery';
	?>
	<div class="c-media">
		<?php if ($type === 'Gallery'):
			$gallery = $media['gallery'] ?? [];
			$gallery_layout = $media['gallery_layout'] ?? 'carousel';

			if (!empty($gallery)):

				if ($gallery_layout === 'carousel'):

					if (count($gallery) === 1):
						p_image($gallery[0]);
					else:
						$flickity_json = !empty($carousel_options)
							? json_encode($carousel_options, JSON_UNESCAPED_SLASHES)
							: '{}';
						?>
						<div class="c-media__gallery--carousel" data-flickity='<?php echo $flickity_json ?>'>
							<?php foreach ($gallery as $image): ?>
								<div class="carousel-cell">
									<?php p_image($image); ?>
								</div>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

				<?php elseif (in_array($gallery_layout, ['grid', 'grid_lightbox'], true)): ?>
					<div class="c-media__gallery--grid">
						<?php
						$images_to_show = !empty($max_images) ? array_slice($gallery, 0, $max_images) : $gallery;

						foreach ($images_to_show as $image) {
							p_image($image, $gallery_layout === 'grid_lightbox', $gallery_id);
						}
						?>
					</div>
				<?php endif; ?>

			<?php endif;
		endif; ?>

		<?php
		if ($type === 'Video'):
			$video = $media['video'] ?? '';
			$video_thumbnail = $media['video_thumbnail'] ?? '';

			if ($video):
				?>
				<video class="c-media__video" playsinline autoplay muted loop <?php echo $video_thumbnail ? 'poster="' . esc_url($video_thumbnail) . '"' : ''; ?>>
					<source src="<?php echo esc_url($video); ?>" type="video/mp4">
				</video>
			<?php endif;
		endif; ?>
	</div>
	<?php
}