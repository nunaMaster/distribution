<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Render a modal component with trigger button.
 *
 * @param string $modal_id     Unique ID of the modal.
 * @param string $button_label Label for the trigger button.
 * @param string $content      Content inside the modal.
 * @param string $modal_class  Additional modal CSS classes.
 */
function c_modal($modal_id, $button_label = '', $content = '')
{
	if (empty($modal_id)) {
		return;
	}

	?>
	<button class="p-button" data-show-dialog="<?php echo esc_attr($modal_id); ?>">
		<?php echo esc_html($button_label); ?>
	</button>

	<dialog class="c-modal" id="<?php echo esc_attr($modal_id); ?>">
		<div class="c-modal__content">
			<button class="c-modal__close-button" data-close-dialog aria-label="Close modal">
				<svg width="24" height="24" stroke-width="1.5" viewBox="0 0 24 24" fill="none"
					xmlns="http://www.w3.org/2000/svg" color="#000000">
					<path d="M6.76 17.24L12 12M17.24 6.76L12 12M12 12L6.76 6.76M12 12L17.24 17.24" stroke="currentColor"
						stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
				</svg>
			</button>
			<?php echo $content; ?>
		</div>
	</dialog>
	<?php
}