</main>

<footer class="c-footer">
	<div class="layout c-footer__top">
		<div class="c-footer__logo">
			<?php $footer_logo_id = get_theme_mod('footer_logo'); ?>

			<?php if ($footer_logo_id): ?>
				<a class="c-footer__logo-link" href="<?php echo esc_url(home_url()) ?>">
					<?php echo wp_get_attachment_image($footer_logo_id, 'medium_large') ?>
				</a>
			<?php elseif (has_custom_logo()): ?>
				<?php the_custom_logo(); ?>
			<?php else: ?>
				<a class="c-footer__logo-link" href="<?php echo esc_url(home_url()) ?>">
					<h2><?php echo esc_html(get_bloginfo('name')); ?></h2>
				</a>
			<?php endif; ?>
		</div>

		<?php if (has_nav_menu('footer')): ?>
			<nav class="c-footer__nav">
				<?php
				wp_nav_menu(array(
					'theme_location' => 'footer',
					'container' => false,
					'menu_id' => '',
					'echo' => true,
					'fallback_cb' => false
				));
				?>
			</nav>
		<?php endif; ?>

		<?php
		$telephone = get_field('telephone', 'option');
		$email = get_field('email', 'option');
		$address = get_field('address', 'option');
		$locality = get_field('locality', 'option');
		$country = get_field('country', 'option');
		$social_media = get_field('social_media', 'option');
		?>
		<div class="c-footer__info">
			<div class="info__contact">
				<p class="info__hotel-name">
					<?php echo get_bloginfo('name'); ?>
				</p>
				<?php if ($telephone): ?>
					<p class="info__telephone">
						<a href="tel:<?php echo esc_html($telephone); ?>">
							<?php echo esc_html($telephone); ?>
						</a>
					</p>
				<?php endif; ?>
				<?php if ($email): ?>
					<p class="info__email">
						<a href="mailto:<?php echo esc_html($email); ?>">
							<?php echo esc_html($email); ?>
						</a>
					</p>
				<?php endif; ?>
				<?php if ($address): ?>
					<p class="info__address">
						<?php echo esc_html($address); ?>
					</p>
				<?php endif; ?>
				<?php if ($locality): ?>
					<p class="info__locality">
						<?php echo esc_html($locality); ?>
					</p>
				<?php endif; ?>
				<?php if ($country): ?>
					<p class="info__country">
						<?php echo esc_html($country); ?>
					</p>
				<?php endif; ?>
			</div>
			<?php if ($social_media): ?>
				<ul class="info__socials">
					<?php foreach ($social_media as $social): ?>
						<li class="info__social">
							<a href="<?php echo esc_url($social['url']); ?>" target="_blank" rel="noopener noreferrer">
								<?php
								$platform = strtolower($social['platform']);
								p_icon($platform);
								?>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<?php $copyright = get_field('copyright', 'option'); ?>
	</div>
	<div class="layout c-footer__bottom">
		<?php echo do_shortcode('[nuna_wpml_language_selector class="c-footer__languages"]') ?>
		<?php if (!empty($copyright)): ?>
			<div class="c-footer__copyright">
				<?php echo esc_html($copyright); ?>
			</div>
		<?php endif; ?>
		<!-- <div class="c-footer__legal">
			<?php
			$privacy_policy = get_permalink(get_option('wp_page_for_privacy_policy'));
			if ($privacy_policy): ?>
				<a href="<?php echo esc_url($privacy_policy); ?>" class="c-footer__legal-link">
					<?php esc_html_e('Privacy Policy', 'nunaBase'); ?>
				</a>
			<?php endif; ?>
			<a href="<?php echo esc_url(home_url('/cookie-policy')); ?>" class="c-footer__legal-link">
				<?php esc_html_e('Cookie Policy', 'nunaBase'); ?>
			</a>
		</div> -->
	</div>
</footer>

<?php wp_footer(); ?>

<div class="mobile-action-bar">
	<div class="mobile-action-bar__contact">
		<button class="contact__icon p-button p-button--secondary">
			<svg data-slot="icon" fill="none" stroke-width="1.5" stroke="currentColor" viewBox="0 0 24 24"
				xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
				<path stroke-linecap="round" stroke-linejoin="round"
					d="M10.5 1.5H8.25A2.25 2.25 0 0 0 6 3.75v16.5a2.25 2.25 0 0 0 2.25 2.25h7.5A2.25 2.25 0 0 0 18 20.25V3.75a2.25 2.25 0 0 0-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3">
				</path>
			</svg>
		</button>
		<ul class="contact__list">
			<?php if (!empty($telephone)): ?>
				<li class="contact__item">
					<a class="p-button p-button--secondary" href="tel:<?php echo esc_attr($telephone); ?>">
						<?php echo esc_html($telephone); ?>
					</a>
				</li>
			<?php endif; ?>

			<?php if (!empty($social_media)): ?>
				<?php foreach ($social_media as $social): ?>
					<?php
					$platform = strtolower(trim($social['platform']));
					$url = esc_url($social['url']);
					$name = esc_html($social['platform']);
					?>
					<?php if ($platform === 'whatsapp'): ?>
						<li class="contact__item">
							<a class="p-button p-button--secondary" href="<?php echo $url; ?>" target="_blank"
								rel="noopener noreferrer">
								<?php echo $name; ?>
							</a>
						</li>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>

	<?php $hotel_id = get_field('hotel_id', 'option'); ?>
	<?php if (!empty($hotel_id)): ?>
		<?php c_modal('mirai-modal', 'Reservar', '<div data-mirai-component="finder" data-layout="column"  data-desktop="false"></div>') ?>
	<?php endif; ?>
</div>

<?php if (!empty($hotel_id)): ?>
	<script async type="module" defer src="https://static.mirai.com/core/index.js"></script>
<?php endif; ?>
</body>

</html>