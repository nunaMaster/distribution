<?php get_header(); ?>

<section class="s-not-found">
	<div class="layout" style="padding-block: 12rem 6rem; text-align: center; align-items: center;">
		<h1 class="p-title p-title--md">
			Oops! Page Not Found
		</h1>
		<p>
			Sorry, the page you are looking for doesn't exist. Here are some helpful links to get you back on track:
		</p>

		<a href="<?php echo home_url(); ?>" class="p-button">
			Back to Homepage
		</a>
	</div>
</section>

<?php get_footer();