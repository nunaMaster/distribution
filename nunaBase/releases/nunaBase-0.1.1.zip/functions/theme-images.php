<?php
/**
 * Configure image sizes for the theme.
 */

// Update default WordPress image size options when the theme is activated.
function theme_update_image_options()
{
	$image_options = [
		'thumbnail_size_w' => 350,
		'thumbnail_size_h' => 350,
		'thumbnail_crop' => 1,
		'medium_size_w' => 700, // Increased for better Retina display quality
		'medium_size_h' => 0,   // No forced cropping
		'large_size_w' => 1400, // Suitable for standard desktop screens
		'large_size_h' => 0,    // No forced cropping
		'medium_large_size_w' => 1000, // Ideal for tablet and small desktop screens
		'medium_large_size_h' => 0,    // No forced cropping
	];

	foreach ($image_options as $option => $value) {
		update_option($option, $value);
	}
}

add_action('after_switch_theme', 'theme_update_image_options');

// Register custom image sizes.
function theme_setup_images()
{
	// Remove default retina image sizes if they exist.
	remove_image_size('1536x1536');
	remove_image_size('2048x2048');

	// Add custom image sizes for different use cases.
	add_image_size('banner', 1920, 800, true);         // Full-width hero banner for desktop
	add_image_size('hero-small', 1280, 500, true);     // Hero sections for tablets or smaller sections
	add_image_size('gallery-thumb', 600, 400, true);   // Thumbnails for image galleries
}

add_action('after_setup_theme', 'theme_setup_images');