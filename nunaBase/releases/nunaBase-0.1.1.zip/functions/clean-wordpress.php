<?php
/**
 * Theme Cleanup - Optimize WordPress frontend & admin for hotel base theme.
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Frontend Cleanup
 */
add_action('init', function () {
	// Remove unnecessary head tags
	remove_action('wp_head', 'wp_generator');
	remove_action('wp_head', 'feed_links', 2);
	remove_action('wp_head', 'feed_links_extra', 3);
	remove_action('wp_head', 'rsd_link');
	remove_action('wp_head', 'wlwmanifest_link');
	remove_action('wp_head', 'wp_shortlink_wp_head');
	remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10);
	remove_action('wp_head', 'print_emoji_detection_script', 7);
	remove_action('wp_print_styles', 'print_emoji_styles');
	remove_action('wp_head', 'wp_oembed_add_discovery_links');
	remove_action('wp_head', 'wp_oembed_add_host_js');
	remove_filter('oembed_dataparse', 'wp_filter_oembed_result', 10);
	remove_action('rest_api_init', 'wp_oembed_register_route');
	wp_deregister_script('wp-embed');

	// Unregister default Posts and Categories/Tags
	unregister_post_type('post');
	unregister_taxonomy('category');
	unregister_taxonomy('post_tag');

	// Disable comments and trackbacks globally
	foreach (get_post_types() as $post_type) {
		if (post_type_supports($post_type, 'comments')) {
			remove_post_type_support($post_type, 'comments');
			remove_post_type_support($post_type, 'trackbacks');
		}
	}
}, 100);

/**
 * Disable Gutenberg and Block Editor
 */
add_filter('use_block_editor_for_post_type', function ($use_block_editor, $post_type) {
	$disabled = ['post', 'page', 'room']; // Add CPT if needed
	return in_array($post_type, $disabled, true) ? false : $use_block_editor;
}, 10, 2);

add_action('after_setup_theme', function () {
	remove_theme_support('core-block-patterns');
	remove_theme_support('widgets-block-editor');
});

/**
 * Disable frontend block styles (global-styles, block-library)
 */
add_action('wp_enqueue_scripts', function () {
	wp_dequeue_style('wp-block-library');
	wp_dequeue_style('wp-block-library-theme');
	wp_dequeue_style('global-styles');
	wp_dequeue_style('classic-theme-styles');
}, 20);

/**
 * Disable jQuery on production
 */
if ((!defined('WP_ENVIRONMENT_TYPE') || 'local' !== WP_ENVIRONMENT_TYPE) && !WP_DEBUG) {
	add_action('wp_enqueue_scripts', function () {
		if (!is_admin()) {
			wp_deregister_script('jquery');
			wp_deregister_script('jquery-core');
			wp_deregister_script('jquery-migrate');
		}
	}, 100);
}

/**
 * 🧹 Admin Cleanup
 */
add_action('admin_init', function () {
	// Hide admin notices for non-admins
	if (!current_user_can('manage_options')) {
		remove_all_actions('admin_notices');
	}

	// Remove Editor from Pages
	remove_post_type_support('page', 'editor');
}, 1);

/**
 * Clean up Dashboard Widgets
 */
add_action('wp_dashboard_setup', function () {
	remove_meta_box('dashboard_quick_press', 'dashboard', 'side');
	remove_meta_box('dashboard_primary', 'dashboard', 'side');
	remove_meta_box('dashboard_activity', 'dashboard', 'normal');
	remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal');
	remove_meta_box('dashboard_site_health', 'dashboard', 'normal');
});

/**
 * Remove unwanted admin menus
 */
add_action('admin_menu', function () {
	remove_menu_page('edit.php');          // Posts
	remove_menu_page('edit-comments.php'); // Comments
});

/**
 * Clean Admin Bar
 */
add_action('admin_bar_menu', function ($wp_admin_bar) {
	$wp_admin_bar->remove_node('comments');
	$wp_admin_bar->remove_node('new-post');
	$wp_admin_bar->remove_node('customize');
	$wp_admin_bar->remove_node('new-page');
}, 999);

/**
 * Disable RSS Feeds
 */
function nbn_disable_feeds()
{
	wp_send_json_error(
		['message' => __('Feeds are disabled. Visit our homepage.', 'nunabase')],
		410
	);
}
add_action('do_feed', 'nbn_disable_feeds', 1);
add_action('do_feed_rdf', 'nbn_disable_feeds', 1);
add_action('do_feed_rss', 'nbn_disable_feeds', 1);
add_action('do_feed_rss2', 'nbn_disable_feeds', 1);
add_action('do_feed_atom', 'nbn_disable_feeds', 1);

/**
 * Redirect attachment pages to home
 */
add_action('template_redirect', function () {
	if (is_attachment()) {
		wp_redirect(home_url(), 301);
		exit;
	}
});

/**
 * Remove default Widgets
 */
add_action('widgets_init', function () {
	unregister_widget('WP_Widget_Recent_Posts');
	unregister_widget('WP_Widget_Recent_Comments');
	unregister_widget('WP_Widget_Categories');
	unregister_widget('WP_Widget_Archives');
	unregister_widget('WP_Widget_Meta');
	unregister_widget('WP_Widget_Search');
	unregister_widget('WP_Widget_Text');
	unregister_widget('WP_Widget_Tag_Cloud');
	unregister_widget('WP_Widget_Calendar');
}, 11);