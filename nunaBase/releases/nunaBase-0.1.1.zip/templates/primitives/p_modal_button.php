<?php
/**
 * Modal Trigger Button.
 *
 * @param  string  $id  The unique ID of the modal to open.
 * @param  string  $label  The button text.
 * @param  string  $icon  SVG markup, text, or file name (without extension).
 * @param  string  $class  Additional CSS classes for styling.
 */
function p_modal_button($id, $label = '', $icon = '', $class = '')
{
	?>
	<button data-show-dialog="<?php echo esc_attr($id) ?>" class="p-button <?php echo esc_attr($class) ?>">
		<?php
		// If $icon is raw SVG markup or text (e.g., "X"), output it directly
		if (!empty($icon)) {
			if (strpos($icon, '<svg') !== false || strlen($icon) <= 3) {
				echo $icon;
			} else {
				// Otherwise, assume it's a file name and attempt to load the corresponding icon
				$icon_style = get_theme_mod('icon_style', 'solid'); // Default to 'solid'
				$icon_path = "src/assets/icons/{$icon_style}/{$icon}.svg";
				$full_path = get_template_directory() . '/' . $icon_path;

				if (file_exists($full_path)) {
					include $full_path;
				}
			}
		}
		?>

		<?php if (!empty($label)): ?>
			<span><?php echo esc_html($label) ?></span>
		<?php endif; ?>
	</button>
	<?php
}