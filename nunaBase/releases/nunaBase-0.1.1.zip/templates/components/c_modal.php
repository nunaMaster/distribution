<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Modal Component.
 *
 * @param  string  $id  The unique ID of the modal.
 * @param  string  $content  The content inside the modal.
 * @param  string  $class  Additional CSS classes for styling.
 */
function c_modal($id, $content = '', $class = '')
{
	?>
	<dialog class="c-modal <?php echo esc_attr($class) ?>" id="<?php echo esc_attr($id) ?>">
		<div class="c-modal__content">
			<?php echo $content ?>
			<button class="p-button p-button--primary" data-close-dialog>Close</button>
		</div>
	</dialog>
	<?php
}