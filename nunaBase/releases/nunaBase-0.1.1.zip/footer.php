</main>

<footer class="c-footer">
	<php class="layout">
		<div class="c-footer__logo">
			<?php $footer_logo_id = get_theme_mod('footer_logo'); ?>

			<?php if ($footer_logo_id): ?>
				<a class="c-footer__logo-link" href="<?php echo esc_url(home_url()) ?>">
					<?php echo wp_get_attachment_image($footer_logo_id, 'medium_large') ?>
				</a>
			<?php elseif (has_custom_logo()): ?>
				<?php the_custom_logo(); ?>
			<?php else: ?>
				<a class="c-footer__logo-link" href="<?php echo esc_url(home_url()) ?>">
					<h2><?php echo esc_html(get_bloginfo('name')); ?></h2>
				</a>
			<?php endif; ?>
		</div>

		<?php if (has_nav_menu('footer')): ?>
			<nav class="c-footer__nav">
				<?php
				wp_nav_menu(array(
					'theme_location' => 'footer',
					'container' => false,
					'menu_id' => '',
					'echo' => true,
					'fallback_cb' => false
				));
				?>
			</nav>
		<?php endif; ?>

		<?php
		$telephone = get_field('telephone', 'option');
		$email = get_field('email', 'option');
		$address = get_field('address', 'option');
		$locality = get_field('locality', 'option');
		$country = get_field('country', 'option');
		$social_media = get_field('social_media', 'option');
		?>
		<div class="c-footer__info">
			<div class="info__contact">
				<p class="info__hotel-name">
					<?php echo get_bloginfo('name'); ?>
				</p>
				<?php if ($telephone): ?>
					<p class="info__telephone">
						<a href="tel:<?php echo esc_html($telephone); ?>">
							<?php echo esc_html($telephone); ?>
						</a>
					</p>
				<?php endif; ?>
				<?php if ($email): ?>
					<p class="info__email">
						<a href="mailto:<?php echo esc_html($email); ?>">
							<?php echo esc_html($email); ?>
						</a>
					</p>
				<?php endif; ?>
				<?php if ($address): ?>
					<p class="info__address">
						<?php echo esc_html($address); ?>
					</p>
				<?php endif; ?>
				<?php if ($locality): ?>
					<p class="info__locality">
						<?php echo esc_html($locality); ?>
					</p>
				<?php endif; ?>
				<?php if ($country): ?>
					<p class="info__country">
						<?php echo esc_html($country); ?>
					</p>
				<?php endif; ?>
			</div>
			<?php if ($social_media): ?>
				<ul class="info__socials">
					<?php foreach ($social_media as $social): ?>
						<li class="info__social">
							<a href="<?php echo esc_url($social['url']); ?>" target="_blank" rel="noopener noreferrer">
								<?php
								$platform = strtolower($social['platform']);
								p_icon($platform);
								?>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<?php $copyright = get_field('copyright', 'option'); ?>
	</php>
	<div class="layout c-footer__bottom">
		<?php if (!empty(do_action('wpml_add_language_selector'))): ?>
			<div class="c-footer__languages">
				<?php echo do_action('wpml_add_language_selector'); ?>
			</div>
		<?php endif; ?>
		<?php if (!empty($copyright)): ?>
			<div class="c-footer__copyright">
				<?php echo esc_html($copyright); ?>
			</div>
		<?php endif; ?>
		<div class="c-footer__legal">
			<?php
			$privacy_policy = get_permalink(get_option('wp_page_for_privacy_policy'));
			if ($privacy_policy): ?>
				<a href="<?php echo esc_url($privacy_policy); ?>" class="c-footer__legal-link">
					<?php esc_html_e('Privacy Policy', 'nunaBase'); ?>
				</a>
			<?php endif; ?>
			<a href="<?php echo esc_url(home_url('/cookie-policy')); ?>" class="c-footer__legal-link">
				<?php esc_html_e('Cookie Policy', 'nunaBase'); ?>
			</a>
		</div>
	</div>
</footer>

<?php $hotel_id = get_field('hotel_id', 'option'); ?>
<?php if (!empty($hotel_id)): ?>
	<div class="mirai-finder" data-mirai-component="finder"></div>
	<script async type="module" defer src="https://static.mirai.com/core/index.js"></script>
<?php endif; ?>

<?php wp_footer(); ?>

</body>

</html>