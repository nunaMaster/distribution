<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Render the advantages component.
 *
 * @param  array  $advantages  An array of advantages data.
 */
function c_advantages($advantages)
{
	if (empty($advantages)) {
		return;
	}

	echo '<div class="c-advantages">';

	foreach ($advantages as $advantage) {
		$icon = $advantage['p_icon'] ?? '';
		$content = $advantage['content'] ?? [];

		echo '<div class="advantage">';

		if ($icon) {
			p_icon($icon);
		}

		if ($content) {
			echo '<div class="advantage__content">';

			foreach ($content as $block) {
				$layout = $block['acf_fc_layout'] ?? '';

				if (!$layout) {
					continue;
				}

				switch ($layout) {
					case 'label':
						p_title($block['tag'] ?? 'h3', $block['title'] ?? '', $block['variation'] ?? '');
						break;

					case 'description':
						if (!empty($block['description'])) {
							echo '<div class="advantage__content-description">' . wp_kses_post($block['description']) . '</div>';
						}
						break;
				}
			}

			echo '</div>';
		}

		echo '</div>';
	}

	echo '</div>';
}