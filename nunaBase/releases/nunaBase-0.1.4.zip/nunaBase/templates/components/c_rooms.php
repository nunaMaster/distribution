<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Rooms Component.
 *
 * @param array  $rooms             Array of post IDs (rooms).
 * @param string $layout            Layout type: 'carousel' or 'grid'. Default: 'carousel'.
 * @param bool   $show_view_button  Whether to show the "View Room" button.
 */

function c_rooms($rooms, $layout = 'carousel', $show_view_button = false)
{
	if (empty($rooms) || !is_array($rooms)) {
		return;
	}

	$rooms_query = new WP_Query([
		'post_type' => 'room',
		'posts_per_page' => -1,
		'post__in' => $rooms,
		'orderby' => 'post__in',
	]);

	if (!$rooms_query->have_posts()) {
		return;
	}

	$is_carousel = $layout === 'carousel';
	$list_class = "c-rooms c-rooms--" . esc_attr($layout);
	$carousel_attrs = $is_carousel
		? ' data-flickity=\'' . json_encode([
			'cellAlign' => 'left',
			'contain' => true,
			'pageDots' => false,
		]) . '\''
		: '';
	?>

	<div class="<?php echo $list_class; ?>" <?php echo $carousel_attrs; ?>>
		<?php
		while ($rooms_query->have_posts()):
			$rooms_query->the_post();
			$gallery = get_field('gallery');

			if ($is_carousel) {
				echo '<div class="carousel-room">';
			}
			?>
			<article <?php post_class('c-room c-card'); ?>>
				<?php if (!empty($gallery)): ?>
					<div class="c-room__gallery-wrapper c-card__gallery-wrapper">
						<div class="c-room__gallery c-card__gallery"
							data-flickity='{"draggable": false, "wrapAround": true, "pageDots": false}'>
							<?php foreach ($gallery as $gallery_image): ?>
								<div class="carousel-image">
									<a href="<?php echo wp_get_attachment_image_url($gallery_image['ID'], 'full') ?>"
										data-fancybox="room-gallery-<?php the_ID(); ?>">
										<?php p_image($gallery_image['ID']); ?>
									</a>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php elseif (has_post_thumbnail()): ?>
					<div class="c-room__image">
						<?php the_post_thumbnail('medium_large'); ?>
					</div>
				<?php endif; ?>

				<div class="c-room__content">
					<div class="c-room__title p-title p-title--sm">
						<?php the_title(); ?>
					</div>

					<?php if (!empty(get_the_content())): ?>
						<div class="c-room__description default-style">
							<?php echo wp_kses_post(get_the_content()); ?>
						</div>
					<?php endif; ?>

					<?php if ($show_view_button): ?>
						<a href="<?php the_permalink(); ?>" class="p-button">
							<?php esc_html_e('View Room', 'nunabase'); ?>
						</a>
					<?php endif; ?>
				</div>
			</article>
			<?php
			if ($is_carousel) {
				echo '</div>';
			}
		endwhile;
		wp_reset_postdata();
		?>
	</div>

	<?php
}
