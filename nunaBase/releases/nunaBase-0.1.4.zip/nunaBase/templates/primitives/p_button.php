<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Generate an accessible, semantic button link with optional icon and styles.
 *
 * @param string $icon       Icon name to render via p_icon().
 * @param array  $link       ACF link array with 'url', 'title', 'target'.
 * @param string $variation  Style variation: '1' (default), '2' (secondary), '3' (link).
 */
function p_button($icon, $link, $variation = '1')
{
	if (empty($link) || !isset($link['url'], $link['title'])) {
		return;
	}

	$url = esc_url($link['url']);
	$label = trim($link['title']);
	$target = !empty($link['target']) ? esc_attr($link['target']) : '_self';

	$class_map = [
		'1' => '',
		'2' => 'p-button--secondary',
		'3' => 'p-button--link',
	];
	$class = 'p-button ' . ($class_map[$variation] ?? '');

	$rel = $target === '_blank' ? ' rel="noopener noreferrer"' : '';

	echo '<a href="' . $url . '" class="' . esc_attr($class) . '" target="' . $target . '"' . $rel . '>';

	if ($icon) {
		p_icon($icon);
	}

	if ($label) {
		echo '<span class="p-button__label">' . esc_html($label) . '</span>';
	}

	echo '</a>';
}