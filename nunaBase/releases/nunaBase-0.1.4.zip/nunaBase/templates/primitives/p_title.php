<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Output a semantic, accessible, SEO-friendly title.
 *
 * @param string $tag HTML tag to use (h1, h2, h3, div).
 * @param string $title The visible text content.
 * @param string $variation The style variation (1, 2, 3).
 */
function p_title($tag = 'h2', $title = '', $variation = '2')
{
	if (!$title) {
		return;
	}

	$class_map = [
		'1' => 'p-title--lg',
		'2' => 'p-title--md',
		'3' => 'p-title--sm'
	];

	$tag = esc_html($tag);
	$class = 'p-title ' . $class_map[$variation];

	echo "<{$tag} class=\"" . esc_attr($class) . "\">" . esc_html($title) . "</{$tag}>";
}