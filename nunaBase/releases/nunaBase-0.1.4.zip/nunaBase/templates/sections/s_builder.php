<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Section Builder
 *
 * @param array $section {
 *     The section configuration array.
 *
 *     @type array  $content             Flexible content block containing 'content_list'.
 *     @type array  $builder_blocks      Flexible block group, each containing 'content', 'media', and optional 'bg_image'.
 *     @type int    $builder_bg_image    Attachment ID for section background image.
 *     @type string $classes             Additional classes for the wrapper section.
 *     @type int    $builder_max_images  Max image count for media sliders.
 *     @type string $id                  Section ID.
 * }
 */

$content = $section['content'] ?? null;
$media = build_media_array($section);
$show_blocks = $section['builder_show_blocks'] ?? false;
$blocks = $section['builder_blocks'] ?? [];
$bg_image = $section['builder_bg_image'] ?? null;
$classes = $section['classes'] ?? '';
$max_images = $section['builder_max_images'] ?? null;

// Return early if no content or blocks
if (empty($content) && empty($blocks) && empty($media)) {
	return;
}

// Build section background style
$style = '';
if ($bg_image && ($bg_url = wp_get_attachment_image_url($bg_image, 'full'))) {
	$style = ' style="--bg-image: url(' . esc_url($bg_url) . ');"';
}
?>

<section class="s-builder <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php if ($content && $show_blocks): ?>
			<div class="s-builder__content-group">
			<?php endif; ?>

			<?php if ($content): ?>
				<div class="s-builder__content">
					<?php c_content($content); ?>
				</div>
			<?php endif; ?>

			<?php if (!empty($show_blocks)): ?>
				<div class="s-builder__blocks">
					<?php foreach ($blocks as $block_key => $block):
						$block_content = $block['content'] ?? null;
						$block_media = build_media_array($block);
						$block_bg_image = $block['bg_image'] ?? null;

						if (empty($block_content) && empty($block_media)) {
							continue;
						}

						$block_style = '';
						if ($block_bg_image && ($block_bg_url = wp_get_attachment_image_url($block_bg_image, 'full'))) {
							$block_style = ' style="--block-bg-image: url(' . esc_url($block_bg_url) . ');"';
						}
						?>
						<div class="s-builder__block" <?php echo $block_style; ?>>
							<?php if ($block_content): ?>
								<div class="s-builder__block-content">
									<?php c_content($block_content); ?>
								</div>
							<?php endif; ?>

							<?php if ($block_media): ?>
								<div class="s-builder__block-media">
									<?php c_media($block_media, [
										'draggable' => false,
										'wrapAround' => true,
										'pageDots' => false
									], "block-gallery-{$block_key}", $max_images); ?>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ($content && $show_blocks): ?>
			</div> <!-- /.s-builder__content-group -->
		<?php endif; ?>

		<?php if ($media): ?>
			<div class="s-builder__media">
				<?php c_media($media, [
					'draggable' => false,
					'wrapAround' => true,
					'pageDots' => false
				], "section-gallery-{$section_id}", $max_images); ?>
			</div>
		<?php endif; ?>
	</div>
</section>