<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Gallery Content Section Template
 *
 * @param array  $content    Flexible content blocks (ACF layout field).
 * @param array  $cards      List of cards from ACF repeater field.
 * @param string $layout     Layout style: 'carousel' (default) or 'grid'.
 * @param int    $bg_image   Attachment ID of the background image.
 * @param string $classes    Additional CSS class names for the section container.
 */

$content = $section['content'] ?? null;
$layout = $section['cards_layout'] ?? 'carousel';
$cards = $section['cards'] ?? [];
$bg_image = $section['cards_bg_image'] ?? null;
$classes = $section['classes'] ?? '';

if (empty($content) && empty($cards)) {
	return;
}

// Prepare background image CSS variable
$style = '';
if ($bg_image && ($bg_url = wp_get_attachment_image_url($bg_image, 'full'))) {
	$style = ' style="--bg-image: url(' . esc_url($bg_url) . ');"';
}
?>

<section class="s-cards <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php if (!empty($content)): ?>
			<div class="s-cards__content">
				<?php c_content($content); ?>
			</div>
		<?php endif; ?>

		<?php if (!empty($cards)): ?>
			<div class="s-cards__list">
				<?php c_cards($cards, $layout); ?>
			</div>
		<?php endif; ?>
	</div>
</section>