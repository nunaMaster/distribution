<?php
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Rooms Section Template
 *
 * @param array  $content         Flexible content blocks for introduction or context.
 * @param array  $rooms           Array of room post IDs to display.
 * @param string $layout          Layout style: 'carousel' (default) or 'grid'.
 * @param bool   $show_view_button     Whether to display the CTA button in room cards.
 * @param int    $rooms_bg_image  Attachment ID for background image.
 * @param string $classes         Additional CSS class names for styling the section.
 */

$content = $section['content'] ?? null;
$layout = $section['rooms_layout'] ?? 'carousel';
$show_view_button = $section['rooms_show_view_button'] ?? false;
$rooms = $section['rooms'] ?? [];
$bg_image = $section['rooms_bg_image'] ?? null;
$classes = $section['classes'] ?? '';

if (empty($content) && empty($rooms)) {
	return;
}

// Build background style if image is available
$style = '';
if ($bg_image && ($bg_url = wp_get_attachment_image_url($bg_image, 'full'))) {
	$style = ' style="--bg-image: url(' . esc_url($bg_url) . ');"';
}
?>

<section class="s-rooms <?php echo esc_attr($classes); ?>" <?php echo $style; ?>>
	<div class="layout">
		<?php if (!empty($content)): ?>
			<div class="s-rooms__content">
				<?php c_content($content); ?>
			</div>
		<?php endif; ?>

		<?php if (!empty($rooms)): ?>
			<div class="s-rooms__list">
				<?php c_rooms($rooms, $layout, $show_view_button); ?>
			</div>
		<?php endif; ?>
	</div>
</section>