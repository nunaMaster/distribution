<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ==============================================================================
 * WPML Integration for Nuna Theme
 * ==============================================================================
 * - Shortcode: Language switcher
 * - Theme mod string registration
 * - Helper: Get translated theme mod value
 * ==============================================================================
 */

/**
 * Shortcode: [nuna_wpml_language_selector class="your-class"]
 */
function nuna_wpml_language_selector_shortcode($atts)
{
    if (!defined('ICL_SITEPRESS_VERSION')) {
        return '';
    }

    $atts = shortcode_atts([
        'class' => '',
    ], $atts, 'nuna_wpml_language_selector');

    ob_start();
    ?>
    <div class="<?php echo esc_attr($atts['class']); ?>">
        <?php do_action('wpml_add_language_selector'); ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('nuna_wpml_language_selector', 'nuna_wpml_language_selector_shortcode');
