<?php
/**
 * Set up theme support options.
 */
function theme_support() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script'
	) );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 55,
		'width'       => 200,
		'flex-height' => true,
		'flex-width'  => true,
		'header-text' => array( 'site-title', 'site-description' ),
	) );
}

add_action( 'after_setup_theme', 'theme_support' );

function custom_title_separator( $sep ) {
	return '|'; // Set your desired separator, e.g., |, -, ~, etc.
}

add_filter( 'document_title_separator', 'custom_title_separator' );