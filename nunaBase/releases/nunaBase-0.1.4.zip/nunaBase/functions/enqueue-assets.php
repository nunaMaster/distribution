<?php

/**
 * Enqueue theme styles and scripts with support for Vite manifests and skin-specific styles.
 */
function enqueue_assets()
{
    $theme_uri = get_template_directory_uri();
    $theme_path = get_template_directory();

    // Enqueue third-party library styles and scripts
    wp_enqueue_style('flickity-css', $theme_uri . '/dist/assets/libs/flickity/flickity.min.css');
    wp_enqueue_script('flickity-js', $theme_uri . '/dist/assets/libs/flickity/flickity.pkgd.min.js', [], null, true);

    wp_enqueue_style('fancybox-css', $theme_uri . '/dist/assets/libs/fancybox/fancybox.min.css');
    wp_enqueue_script('fancybox-js', $theme_uri . '/dist/assets/libs/fancybox/fancybox.umd.min.js', [], null, true);

    // Load Vite manifest to enqueue main theme assets
    $manifest_path = $theme_path . '/dist/.vite/manifest.json';
    if (!file_exists($manifest_path)) {
        error_log("Vite manifest not found at {$manifest_path}");
        return;
    }

    $manifest = json_decode(file_get_contents($manifest_path), true);
    if (!$manifest) {
        error_log("Failed to decode Vite manifest JSON.");
        return;
    }

    // Enqueue main CSS from manifest (compiled SCSS)
    $main_css_file = $manifest['src/scss/styles.scss']['file'] ?? '';
    if ($main_css_file) {
        wp_enqueue_style('nuna-style', $theme_uri . '/dist/' . $main_css_file, [], null);
    }

    // Enqueue skin CSS
    $current_domain = get_main_domain_name();
    $host = $_SERVER['HTTP_HOST'] ?? '';

    // Determine if we're in a local/development environment
    $is_local = in_array($host, ['localhost', '127.0.0.1']) ||
        str_ends_with($host, '.local') ||
        str_ends_with($host, '.test');

    // Define paths and URLs for skin assets
    $skin_manifest_path = $is_local
        ? $theme_path . "/dev/skins/.vite/{$current_domain}.manifest.json"
        : ABSPATH . "wp-content/skins/.vite/{$current_domain}.manifest.json";

    $skin_base_url = $is_local
        ? $theme_uri . "/dev/skins/"
        : get_home_url(null, "/wp-content/skins/");

    // Load and decode the skin manifest file
    if (!file_exists($skin_manifest_path)) {
        error_log("Vite skin manifest not found at {$skin_manifest_path}");
        return;
    }

    $skin_manifest = json_decode(file_get_contents($skin_manifest_path), true);
    if (!$skin_manifest) {
        error_log("Failed to decode skin manifest JSON at {$skin_manifest_path}");
        return;
    }

    // Enqueue the skin-specific CSS file
    $skin_css_file = $skin_manifest["src/scss/skins/{$current_domain}.scss"]['file'] ?? '';
    if ($skin_css_file) {
        wp_enqueue_style('skin-style', $skin_base_url . $skin_css_file, [], null);
    }

    /*
    $selected_skin = get_theme_mod('selected_skin', 'nuna');
    if ($selected_skin !== 'nuna') {
        $skin_css_path = $theme_uri . '/dist/assets/skins/' . $selected_skin . '.css';
        wp_enqueue_style('custom-skin', $skin_css_path, [], null);
    }
    */

    // Enqueue main JS from manifest
    $main_js_file = $manifest['src/js/main.js']['file'] ?? '';
    if ($main_js_file) {
        wp_enqueue_script('nuna-script', $theme_uri . '/dist/' . $main_js_file, [], null, true);
    }
}

add_action('wp_enqueue_scripts', 'enqueue_assets');