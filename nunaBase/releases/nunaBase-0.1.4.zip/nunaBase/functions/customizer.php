<?php

// Ensure the Customizer Control class exists before extending it.
if (class_exists('WP_Customize_Control')) {
    /**
     * Custom Reset Control for Theme Customizer.
     */
    class Nuna_Reset_Control extends WP_Customize_Control
    {
        public $type = 'reset';

        /**
         * Render the content for the reset control.
         */
        public function render_content()
        {
            // Build current URL with the reset parameter.
            $reset_url = add_query_arg('reset_theme_options', '1');
            ?>
            <label>
                <span class="customize-control-title"><?php esc_html_e('Reset Options', 'nunabase'); ?></span>
                <a href="<?php echo esc_url($reset_url); ?>" class="button button-secondary">
                    <?php esc_html_e('Reset To Defaults', 'nunabase'); ?>
                </a>
            </label>
            <?php
        }
    }
}

/**
 * Handle theme option reset functionality.
 */
function nuna_reset_theme_options()
{
    if (isset($_GET['reset_theme_options']) && '1' === $_GET['reset_theme_options']) {
        // List all theme mod keys to reset.
        $keys = [
            // 'selected_skin',
            'heading_font',
            'body_font',
            'header_layout',
            'icon_style'
        ];

        // Remove each theme mod.
        foreach ($keys as $key) {
            remove_theme_mod($key);
        }

        // Redirect to same page without the reset query parameter.
        $redirect = remove_query_arg('reset_theme_options');
        wp_safe_redirect($redirect);
        exit;
    }
}
add_action('admin_init', 'nuna_reset_theme_options');

/**
 * Get available skin choices from the skin directory.
 *
 * @return array
 */
function get_skin_choices()
{
    $skin_dir = get_template_directory() . '/dist/assets/skins/';
    $files = glob($skin_dir . '*.css');
    $choices = ['nuna' => 'Nuna'];

    foreach ($files as $file_path) {
        $filename = basename($file_path, '.css');
        $choices[$filename] = ucfirst($filename);
    }

    return $choices;
}

/**
 * Register Customizer settings and controls.
 *
 * @param WP_Customize_Manager $wp_customize
 */
function nuna_customize_register($wp_customize)
{
    // Add footer logo setting and control.
    $wp_customize->add_setting('footer_logo', [
        'default' => '',
        'sanitize_callback' => 'absint',
    ]);

    $wp_customize->add_control(new WP_Customize_Media_Control(
        $wp_customize,
        'footer_logo',
        [
            'label' => __('Footer Logo', 'nunabase'),
            'section' => 'title_tagline',
            'mime_type' => 'image',
            'priority' => 8,
        ]
    ));

    // Main theme settings section.
    $wp_customize->add_section('theme_settings', [
        'title' => __('Theme Settings', 'nunabase'),
        'priority' => 30,
    ]);

    // Include fonts data.
    require get_template_directory() . '/functions/fonts.php';
    $font_choices = nuna_get_available_fonts();

    // Skins
    // $wp_customize->add_setting('selected_skin', [
    //     'default' => 'nuna',
    //     'sanitize_callback' => 'sanitize_text_field',
    // ]);
    // $wp_customize->add_control('selected_skin', [
    //     'label' => __('Skin', 'nunabase'),
    //     'section' => 'theme_settings',
    //     'type' => 'select',
    //     'choices' => get_skin_choices(),
    // ]);

    // Typography settings
    $wp_customize->add_setting('heading_font', [
        'default' => 'Playfair Display',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('heading_font', [
        'label' => __('Heading Font', 'nunabase'),
        'section' => 'theme_settings',
        'type' => 'select',
        'choices' => $font_choices,
    ]);

    $wp_customize->add_setting('body_font', [
        'default' => 'Inter',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('body_font', [
        'label' => __('Body Font', 'nunabase'),
        'section' => 'theme_settings',
        'type' => 'select',
        'choices' => $font_choices,
    ]);

    // Header layout options
    $wp_customize->add_setting('header_layout', [
        'default' => 'default',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('header_layout', [
        'label' => __('Header Layout', 'nunabase'),
        'section' => 'theme_settings',
        'type' => 'select',
        'choices' => [
            'default' => __('Logo Left - Menu Right (Default)', 'nunabase'),
            'logo_left_menu_center' => __('Logo Left - Menu Center (If CTA enabled)', 'nunabase'),
            'logo_left_hamburger_left' => __('Logo Left - Hamburger Left', 'nunabase'),
            'logo_left_hamburger_right' => __('Logo Left - Hamburger Right', 'nunabase'),
            'logo_center_menu_split' => __('Logo Center - Split Menu', 'nunabase'),
            'logo_center_hamburger_left' => __('Logo Center - Hamburger Left', 'nunabase'),
            'logo_center_hamburger_right' => __('Logo Center - Hamburger Right', 'nunabase'),
        ],
    ]);

    // CTA toggle and label
    $wp_customize->add_setting('show_header_cta', [
        'default' => false,
        'sanitize_callback' => 'wp_validate_boolean',
    ]);
    $wp_customize->add_control('show_header_cta', [
        'type' => 'checkbox',
        'section' => 'theme_settings',
        'label' => __('Display Header CTA Button', 'nunabase'),
    ]);

    // Icon style option
    $wp_customize->add_setting('icon_style', [
        'default' => 'solid',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('icon_style', [
        'label' => __('Icon Style', 'nunabase'),
        'type' => 'radio',
        'section' => 'theme_settings',
        'choices' => [
            'solid' => __('Solid', 'nunabase'),
            'outline' => __('Outline', 'nunabase'),
        ],
    ]);

    // Add reset button control
    $wp_customize->add_setting('theme_reset', [
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control(new Nuna_Reset_Control($wp_customize, 'theme_reset', [
        'section' => 'theme_settings',
        'priority' => 100,
    ]));
}
add_action('customize_register', 'nuna_customize_register');

/**
 * Output inline CSS variables to head based on Customizer settings.
 */
function theme_customizer_styles()
{
    $heading_font = get_theme_mod('heading_font', 'Playfair Display');
    $body_font = get_theme_mod('body_font', 'Inter');
    $icon_style = get_theme_mod('icon_style', 'solid');
    ?>
    <style>
        :root {
            --font-heading:
                <?php echo esc_attr($heading_font); ?>
            ;
            --font:
                <?php echo esc_attr($body_font); ?>
            ;
            --icon-style:
                <?php echo esc_attr($icon_style); ?>
            ;
        }
    </style>
    <?php
}
add_action('wp_head', 'theme_customizer_styles');